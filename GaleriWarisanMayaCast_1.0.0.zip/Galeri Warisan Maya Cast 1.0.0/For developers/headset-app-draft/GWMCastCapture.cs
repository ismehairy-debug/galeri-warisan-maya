// Galeri Warisan Maya Cast, headset side: the picture.
//
// DRAFT, not yet compiled in Unity or run on a Quest. Points to settle on
// the headset are marked CHECK.
//
// A separate "spectator" camera follows the visitor's head with a little
// smoothing and renders a flat 16:9 view at a reduced rate. The frame is
// read back without stalling the GPU, turned into a JPEG on a worker thread
// and handed to GWMCastServer. If the worker is still busy when the next
// frame arrives, that frame is skipped, so casting never queues up work.

using System.Threading;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;

namespace GWM.Cast
{
    public sealed class GWMCastCapture : MonoBehaviour
    {
        public GWMCastServer Server;
        /// Layers the laptop should not see (for example a comfort vignette
        /// that is fixed to the visitor's eyes). CHECK against the project.
        public LayerMask HiddenLayers = 0;
        /// CHECK on the headset: whether the read-back rows arrive top-down.
        public bool FlipVertical;
        public float FieldOfView = 68f;

        Camera cam, head;
        RenderTexture rt;
        int width, height, fps = 30, quality = 70, appliedVersion = -1;
        float nextCapture;
        bool renderedLastFrame;
        long renderedPtsMs;

        NativeArray<byte> raw, row;
        int rawWidth, rawHeight;
        long rawPtsMs;
        int rawState;                 // 0 free, 1 filled, 2 being encoded
        Thread worker;
        AutoResetEvent rawReady;
        volatile bool running;

        void OnEnable()
        {
            FlipVertical = SystemInfo.graphicsUVStartsAtTop;
            var go = new GameObject("GWM Cast Camera");
            go.transform.SetParent(transform, false);
            cam = go.AddComponent<Camera>();
            cam.enabled = false;
            running = true;
            rawReady = new AutoResetEvent(false);
            worker = new Thread(EncodeLoop) { IsBackground = true, Name = "GWMCast jpeg" };
            worker.Start();
        }

        void OnDisable()
        {
            running = false;
            rawReady.Set();
            if (worker != null) worker.Join(500);
            // Let any read-back still in flight finish before the buffers go.
            AsyncGPUReadback.WaitAllRequests();
            if (raw.IsCreated) raw.Dispose();
            if (row.IsCreated) row.Dispose();
            if (rt != null) { rt.Release(); Destroy(rt); rt = null; }
            if (cam != null) Destroy(cam.gameObject);
        }

        void Configure(GWMCastServer.Settings s)
        {
            int h = s.MaxHeight, w = h * 16 / 9;
            fps = s.Fps; quality = s.Quality;
            if (w == width && h == height) return;
            if (Volatile.Read(ref rawState) != 0) { appliedVersion = -1; return; } // try again next frame
            width = w; height = h;
            if (rt != null) { rt.Release(); Destroy(rt); }
            rt = new RenderTexture(w, h, 24, RenderTextureFormat.ARGB32) { name = "GWM Cast", antiAliasing = 2 };
            rt.Create();
            cam.targetTexture = rt;
            cam.aspect = (float)w / h;
            if (raw.IsCreated) raw.Dispose();
            if (row.IsCreated) row.Dispose();
            raw = new NativeArray<byte>(w * h * 4, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            row = new NativeArray<byte>(w * 4, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            rawWidth = w; rawHeight = h;
        }

        void MatchHeadCamera()
        {
            head = Camera.main;
            if (head == null) return;
            cam.CopyFrom(head);
            cam.stereoTargetEye = StereoTargetEyeMask.None;   // a flat picture, not a second pair of eyes
            cam.targetTexture = rt;
            cam.fieldOfView = FieldOfView;
            cam.aspect = 16f / 9f;
            cam.cullingMask = head.cullingMask & ~HiddenLayers.value;
            cam.depth = head.depth - 1;
            cam.enabled = false;
            cam.transform.SetPositionAndRotation(head.transform.position, head.transform.rotation);
        }

        void LateUpdate()
        {
            if (Server == null) return;

            // The frame rendered during the previous Update is now on the GPU.
            if (renderedLastFrame)
            {
                renderedLastFrame = false;
                cam.enabled = false;
                if (Server.HasViewer && rt != null)
                {
                    long pts = renderedPtsMs;
                    AsyncGPUReadback.Request(rt, 0, TextureFormat.RGBA32, req => OnReadback(req, pts));
                }
            }

            if (!Server.HasViewer) return;
            if (appliedVersion != Server.SettingsVersion)
            {
                appliedVersion = Server.SettingsVersion;
                Configure(Server.Requested);
            }
            if (rt == null) return;
            if (head == null || head != Camera.main) MatchHeadCamera();
            if (head == null) return;

            // Follow the head, slightly smoothed: raw head motion is tiring
            // to watch on a big screen.
            float dt = Time.unscaledDeltaTime;
            cam.transform.position = Vector3.Lerp(cam.transform.position, head.transform.position, 1f - Mathf.Exp(-dt * 18f));
            cam.transform.rotation = Quaternion.Slerp(cam.transform.rotation, head.transform.rotation, 1f - Mathf.Exp(-dt * 12f));

            float now = Time.unscaledTime;
            if (now >= nextCapture && Volatile.Read(ref rawState) == 0)
            {
                nextCapture = Mathf.Max(nextCapture + 1f / fps, now - 0.5f / fps);
                cam.enabled = true;            // renders once, with this frame
                renderedLastFrame = true;
                renderedPtsMs = (long)(Time.realtimeSinceStartupAsDouble * 1000.0);
            }
        }

        void OnReadback(AsyncGPUReadbackRequest req, long ptsMs)
        {
            if (!running || req.hasError || !raw.IsCreated) return;
            if (req.width != rawWidth || req.height != rawHeight) return;       // size changed meanwhile
            if (Interlocked.CompareExchange(ref rawState, 1, 0) != 0) return;   // worker busy: skip
            var data = req.GetData<byte>();
            if (data.Length != raw.Length) { Volatile.Write(ref rawState, 0); return; }
            raw.CopyFrom(data);
            rawPtsMs = ptsMs;
            rawReady.Set();
        }

        void EncodeLoop()
        {
            while (running)
            {
                rawReady.WaitOne(250);
                if (!running) return;
                if (Interlocked.CompareExchange(ref rawState, 2, 1) != 1) continue;
                try
                {
                    int w = rawWidth, h = rawHeight, stride = w * 4;
                    if (FlipVertical)
                    {
                        for (int y = 0; y < h / 2; y++)
                        {
                            int a = y * stride, b = (h - 1 - y) * stride;
                            NativeArray<byte>.Copy(raw, a, row, 0, stride);
                            NativeArray<byte>.Copy(raw, b, raw, a, stride);
                            NativeArray<byte>.Copy(row, 0, raw, b, stride);
                        }
                    }
                    // CHECK on the headset: colours. The render texture holds
                    // sRGB bytes, so no conversion should be needed.
                    var jpg = ImageConversion.EncodeNativeArrayToJPG(raw, GraphicsFormat.R8G8B8A8_SRGB, (uint)w, (uint)h, 0, quality);
                    try
                    {
                        var server = Server;
                        if (server != null)
                        {
                            var buf = server.Rent(jpg.Length);
                            NativeArray<byte>.Copy(jpg, 0, buf, GWMCastServer.MediaHeader, jpg.Length);
                            server.OfferVideo(buf, jpg.Length, rawPtsMs);
                        }
                    }
                    finally { jpg.Dispose(); }
                }
                catch (System.Exception e)
                {
                    Debug.LogWarning("GWM cast: picture skipped: " + e.Message);
                }
                finally
                {
                    Volatile.Write(ref rawState, 0);
                }
            }
        }
    }
}
