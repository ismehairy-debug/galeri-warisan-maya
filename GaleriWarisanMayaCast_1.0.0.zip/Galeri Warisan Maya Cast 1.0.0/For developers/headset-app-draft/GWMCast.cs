// Galeri Warisan Maya Cast, headset side: the switch that ties it together.
//
// DRAFT, not yet compiled in Unity or run on a Quest.
//
// Use from the app's start-up prompt:
//
//     GWMCast.Ensure().StartCasting();   // visitor/staff chose "Cast to laptop"
//     // ... or do nothing at all for "Skip": no socket is ever opened.
//
// While casting, read State / ViewerName / LocalAddress to show
// "Waiting for the laptop (this headset is 192.168.1.23)" or
// "Showing on DESKTOP-ABC" in the headset.

using System.Net;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.XR;

namespace GWM.Cast
{
    public sealed class GWMCast : MonoBehaviour
    {
        public enum Phase { Off, Waiting, Live }

        public static GWMCast Instance { get; private set; }
        public Phase State { get; private set; }
        public string ViewerName { get { return server != null ? server.ViewerName : ""; } }
        public string LocalAddress { get; private set; }

        GWMCastServer server;
        GWMCastCapture capture;
        GWMCastAudio audioTap;
        bool lastWorn = true, lastPaused;
        float nextStateCheck;

        public static GWMCast Ensure()
        {
            if (Instance != null) return Instance;
            var go = new GameObject("GWM Cast");
            DontDestroyOnLoad(go);
            Instance = go.AddComponent<GWMCast>();
            return Instance;
        }

        public void StartCasting()
        {
            if (server != null) return;
            LocalAddress = FindLocalAddress();

            var listener = FindObjectOfType<AudioListener>();
            if (listener != null)
            {
                audioTap = listener.GetComponent<GWMCastAudio>();
                if (audioTap == null) audioTap = listener.gameObject.AddComponent<GWMCastAudio>();
            }

            server = new GWMCastServer
            {
                DeviceName = SystemInfo.deviceModel,
                AppVersion = Application.version,
                AudioRate = audioTap != null ? audioTap.Rate : AudioSettings.outputSampleRate,
                AudioChannels = audioTap != null ? audioTap.Channels : 2,
                Log = Debug.Log,
            };
            try
            {
                server.Start();
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("GWM cast could not start: " + e.Message);
                server.Dispose();
                server = null;
                State = Phase.Off;
                return;
            }
            if (audioTap != null) audioTap.Server = server;
            capture = gameObject.AddComponent<GWMCastCapture>();
            capture.Server = server;
            State = Phase.Waiting;
        }

        public void StopCasting()
        {
            if (server == null) return;
            if (capture != null) { Destroy(capture); capture = null; }
            if (audioTap != null) audioTap.Server = null;
            server.Dispose();
            server = null;
            State = Phase.Off;
        }

        void Update()
        {
            if (server == null) return;
            var next = server.HasViewer ? Phase.Live : Phase.Waiting;
            if (next != State)
            {
                State = next;
                if (next == Phase.Live) { lastWorn = true; lastPaused = false; nextStateCheck = 0; }
            }
            if (State == Phase.Live && Time.unscaledTime >= nextStateCheck)
            {
                nextStateCheck = Time.unscaledTime + 0.5f;
                bool worn = true;
                var hmd = InputDevices.GetDeviceAtXRNode(XRNode.Head);
                if (hmd.isValid && hmd.TryGetFeatureValue(CommonUsages.userPresence, out bool present)) worn = present;
                if (worn != lastWorn) { lastWorn = worn; SendState(); }
            }
        }

        void OnApplicationPause(bool paused)
        {
            lastPaused = paused;
            if (server != null) SendState();
        }

        void SendState()
        {
            server.SendState("{\"worn\":" + (lastWorn ? "true" : "false") + ",\"paused\":" + (lastPaused ? "true" : "false") + "}");
        }

        void OnDestroy()
        {
            StopCasting();
            if (Instance == this) Instance = null;
        }

        /// The headset's address on the Wi-Fi, for the "type this on the
        /// laptop" fallback. No packet is sent: connecting a UDP socket only
        /// asks the system which local address it would use.
        static string FindLocalAddress()
        {
            try
            {
                using (var s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
                {
                    s.Connect("10.255.255.255", 9);
                    var ep = s.LocalEndPoint as IPEndPoint;
                    if (ep != null && !IPAddress.IsLoopback(ep.Address) && !ep.Address.Equals(IPAddress.Any)) return ep.Address.ToString();
                }
            }
            catch (System.Exception) { }
            try
            {
                foreach (var a in Dns.GetHostAddresses(Dns.GetHostName()))
                    if (a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a)) return a.ToString();
            }
            catch (System.Exception) { }
            return "";
        }
    }
}
