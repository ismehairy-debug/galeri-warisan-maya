// Galeri Warisan Maya Cast, headset side: the network part.
//
// DRAFT. Written against cast protocol version 1 (see PROTOCOL.md) and the
// laptop app's simulated headset, but not yet compiled in Unity or run on a
// Quest. It uses only .NET sockets and threads, no UnityEngine types, so it
// can be read and tested on its own.
//
// The headset is the server: it listens on TCP 47800, answers discovery
// probes on UDP 47801, and sends pictures and sound to ONE laptop at a time.
// Nothing here opens a socket until Start() is called, and Start() is only
// called after the visitor (or staff) chooses "Cast to laptop".

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace GWM.Cast
{
    public sealed class GWMCastServer : IDisposable
    {
        public const int Proto = 1;
        public const int CastPort = 47800;
        public const int DiscoveryPort = 47801;
        const string AppId = "GWMCAST";
        const string ProbeText = "GWMCAST1?";

        const byte MsgHello = 0x01, MsgVideo = 0x02, MsgAudio = 0x03, MsgState = 0x04,
                   MsgPing = 0x05, MsgPong = 0x06, MsgBye = 0x07,
                   MsgClientHello = 0x10, MsgConfig = 0x11;
        const int MaxIncoming = 64 * 1024;   // the laptop only ever sends small messages
        const int MaxAudioQueued = 100;      // about two seconds

        public struct Settings
        {
            public int MaxHeight, Fps, Quality;
            public static Settings Default { get { return new Settings { MaxHeight = 540, Fps = 30, Quality = 70 }; } }
        }

        // Set these before Start().
        public string DeviceName = "Quest";
        public string AppVersion = "1.1.0";
        public int Width = 960, Height = 540, Fps = 30;
        public int AudioRate = 48000, AudioChannels = 2;
        public Action<string> Log = delegate { };

        // Safe to read from any thread.
        public bool HasViewer { get { return viewer != null; } }
        public string ViewerName { get { var v = viewer; return v != null ? v.Name : ""; } }
        public Settings Requested { get { lock (gate) return requested; } }
        /// Goes up whenever the laptop asks for different picture settings.
        public int SettingsVersion { get { return Volatile.Read(ref settingsVersion); } }

        readonly object gate = new object();
        readonly BufferPool pool = new BufferPool();
        Settings requested = Settings.Default;
        int settingsVersion;
        volatile bool running;
        volatile Viewer viewer;
        TcpListener listener;
        UdpClient udp;
        Thread acceptThread, udpThread;

        public void Start()
        {
            if (running) return;
            running = true;
            listener = new TcpListener(IPAddress.Any, CastPort);
            listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            listener.Start(4);
            acceptThread = new Thread(AcceptLoop) { IsBackground = true, Name = "GWMCast accept" };
            acceptThread.Start();
            try
            {
                udp = new UdpClient(new IPEndPoint(IPAddress.Any, DiscoveryPort));
                udp.EnableBroadcast = true;
                udpThread = new Thread(ProbeLoop) { IsBackground = true, Name = "GWMCast discovery" };
                udpThread.Start();
            }
            catch (Exception e)
            {
                // Discovery is a convenience; the laptop can still find the
                // headset by knocking on the cast port or by typed address.
                Log("cast: discovery unavailable: " + e.Message);
            }
            Log("cast: listening on port " + CastPort);
        }

        public void Dispose()
        {
            if (!running) return;
            running = false;
            var v = viewer;
            if (v != null) v.End();
            try { listener.Stop(); } catch { }
            try { if (udp != null) udp.Close(); } catch { }
        }

        // ---------- Media in (called by the capture and audio components) ----------

        /// Rent a buffer, fill it from index MediaHeader onwards, then hand it
        /// back with OfferVideo/OfferAudio. Keeps the per-frame garbage at zero.
        public const int MediaHeader = 13;
        public byte[] Rent(int payloadBytes) { return pool.Rent(MediaHeader + payloadBytes); }
        public void Return(byte[] buffer) { pool.Return(buffer); }

        public void OfferVideo(byte[] buffer, int jpegBytes, long ptsMs)
        {
            var v = viewer;
            if (v == null) { pool.Return(buffer); return; }
            WriteMediaHeader(buffer, MsgVideo, jpegBytes, ptsMs);
            v.OfferVideo(buffer, MediaHeader + jpegBytes);
        }

        public void OfferAudio(byte[] buffer, int pcmBytes, long ptsMs)
        {
            var v = viewer;
            if (v == null) { pool.Return(buffer); return; }
            WriteMediaHeader(buffer, MsgAudio, pcmBytes, ptsMs);
            v.OfferAudio(buffer, MediaHeader + pcmBytes);
        }

        /// Tell the laptop something about the headset, e.g. {"worn":false}.
        public void SendState(string json)
        {
            var v = viewer;
            if (v != null) v.OfferControl(Frame(MsgState, Encoding.UTF8.GetBytes(json)));
        }

        static void WriteMediaHeader(byte[] b, byte type, int dataBytes, long ptsMs)
        {
            int n = 8 + dataBytes;
            b[0] = type;
            b[1] = (byte)n; b[2] = (byte)(n >> 8); b[3] = (byte)(n >> 16); b[4] = (byte)(n >> 24);
            for (int i = 0; i < 8; i++) b[5 + i] = (byte)(ptsMs >> (8 * i));
        }

        static byte[] Frame(byte type, byte[] payload)
        {
            var b = new byte[5 + payload.Length];
            int n = payload.Length;
            b[0] = type;
            b[1] = (byte)n; b[2] = (byte)(n >> 8); b[3] = (byte)(n >> 16); b[4] = (byte)(n >> 24);
            Buffer.BlockCopy(payload, 0, b, 5, n);
            return b;
        }

        // ---------- Discovery ----------

        void ProbeLoop()
        {
            var probe = Encoding.ASCII.GetBytes(ProbeText);
            while (running)
            {
                try
                {
                    var from = new IPEndPoint(IPAddress.Any, 0);
                    var data = udp.Receive(ref from);
                    if (data.Length != probe.Length) continue;
                    bool same = true;
                    for (int i = 0; i < probe.Length; i++) if (data[i] != probe[i]) { same = false; break; }
                    if (!same || !IsLocal(from.Address)) continue;
                    var reply = Encoding.UTF8.GetBytes(
                        "{\"app\":\"" + AppId + "\",\"proto\":" + Proto + ",\"name\":\"" + Escape(DeviceName) +
                        "\",\"port\":" + CastPort + ",\"ver\":\"" + Escape(AppVersion) +
                        "\",\"busy\":" + (HasViewer ? "true" : "false") + "}");
                    udp.Send(reply, reply.Length, from);
                }
                catch (Exception)
                {
                    if (!running) return;
                    Thread.Sleep(200);
                }
            }
        }

        // ---------- Connections ----------

        void AcceptLoop()
        {
            while (running)
            {
                TcpClient client;
                try { client = listener.AcceptTcpClient(); }
                catch (Exception) { if (!running) return; Thread.Sleep(200); continue; }
                var t = new Thread(() => Greet(client)) { IsBackground = true, Name = "GWMCast greet" };
                t.Start();
            }
        }

        void Greet(TcpClient client)
        {
            try
            {
                client.NoDelay = true;
                client.SendTimeout = 3000;
                client.ReceiveTimeout = 3000;
                var remote = (IPEndPoint)client.Client.RemoteEndPoint;
                var stream = client.GetStream();
                if (!IsLocal(remote.Address)) { client.Close(); return; }

                Viewer v = null;
                lock (gate)
                {
                    if (viewer == null) { v = new Viewer(this, client, stream); viewer = v; }
                }
                if (v == null)
                {
                    var bye = Frame(MsgBye, Encoding.UTF8.GetBytes("{\"reason\":\"busy\"}"));
                    stream.Write(bye, 0, bye.Length);
                    client.Close();
                    return;
                }

                var hello = Frame(MsgHello, Encoding.UTF8.GetBytes(
                    "{\"app\":\"" + AppId + "\",\"proto\":" + Proto + ",\"name\":\"" + Escape(DeviceName) +
                    "\",\"appVersion\":\"" + Escape(AppVersion) + "\",\"width\":" + Width + ",\"height\":" + Height +
                    ",\"fps\":" + Fps + ",\"audioRate\":" + AudioRate + ",\"audioChannels\":" + AudioChannels + "}"));
                stream.Write(hello, 0, hello.Length);

                // Nothing is sent until the laptop introduces itself, so a
                // stray port scanner never receives the picture.
                byte type; byte[] payload;
                if (!ReadMessage(stream, out type, out payload) || type != MsgClientHello)
                {
                    v.Close("no hello");
                    return;
                }
                if (!running) { v.Close("stopped"); return; }
                v.Name = JsonString(Encoding.UTF8.GetString(payload), "name");
                client.ReceiveTimeout = 10000; // the laptop pings every second
                Log("cast: laptop \"" + v.Name + "\" connected from " + remote.Address);
                v.Run();
            }
            catch (Exception e)
            {
                Log("cast: connection failed: " + e.Message);
                try { client.Close(); } catch { }
                lock (gate) { if (viewer != null && viewer.Client == client) viewer = null; }
            }
        }

        static bool ReadExact(NetworkStream s, byte[] b, int n)
        {
            int got = 0;
            while (got < n)
            {
                int r = s.Read(b, got, n - got);
                if (r <= 0) return false;
                got += r;
            }
            return true;
        }

        static bool ReadMessage(NetworkStream s, out byte type, out byte[] payload)
        {
            type = 0; payload = null;
            var hdr = new byte[5];
            if (!ReadExact(s, hdr, 5)) return false;
            int n = hdr[1] | (hdr[2] << 8) | (hdr[3] << 16) | (hdr[4] << 24);
            if (n < 0 || n > MaxIncoming) return false;
            payload = new byte[n];
            if (n > 0 && !ReadExact(s, payload, n)) return false;
            type = hdr[0];
            return true;
        }

        void Dropped(Viewer v)
        {
            lock (gate) { if (viewer == v) viewer = null; }
            Log("cast: laptop disconnected");
        }

        void ApplyConfig(string json)
        {
            var s = Settings.Default;
            int h = JsonInt(json, "maxHeight"), f = JsonInt(json, "fps"), q = JsonInt(json, "quality");
            if (h >= 720) s.MaxHeight = 720; else if (h > 0 && h < 540) s.MaxHeight = 432;
            if (f >= 5 && f <= 60) s.Fps = f;
            if (q >= 20 && q <= 95) s.Quality = q;
            lock (gate) requested = s;
            Interlocked.Increment(ref settingsVersion);
        }

        // ---------- One connected laptop ----------

        sealed class Viewer
        {
            public readonly TcpClient Client;
            public string Name = "";
            readonly GWMCastServer owner;
            readonly NetworkStream stream;
            readonly object q = new object();
            readonly AutoResetEvent wake = new AutoResetEvent(false);
            readonly Queue<Item> audio = new Queue<Item>();
            readonly Queue<byte[]> control = new Queue<byte[]>();
            Item video;
            bool hasVideo;
            volatile bool open = true;
            volatile bool ending;

            struct Item { public byte[] Buf; public int Len; }

            public Viewer(GWMCastServer owner, TcpClient client, NetworkStream stream)
            {
                this.owner = owner; Client = client; this.stream = stream;
            }

            public void OfferVideo(byte[] buf, int len)
            {
                lock (q)
                {
                    if (!open) { owner.pool.Return(buf); return; }
                    // Only the newest picture is kept: if the Wi-Fi is slow
                    // the stream skips pictures rather than falling behind.
                    if (hasVideo) owner.pool.Return(video.Buf);
                    video = new Item { Buf = buf, Len = len };
                    hasVideo = true;
                }
                wake.Set();
            }

            public void OfferAudio(byte[] buf, int len)
            {
                lock (q)
                {
                    if (!open) { owner.pool.Return(buf); return; }
                    if (audio.Count >= MaxAudioQueued)
                        for (int i = 0; i < MaxAudioQueued / 2; i++) owner.pool.Return(audio.Dequeue().Buf);
                    audio.Enqueue(new Item { Buf = buf, Len = len });
                }
                wake.Set();
            }

            public void OfferControl(byte[] framed)
            {
                lock (q) { if (open) control.Enqueue(framed); }
                wake.Set();
            }

            /// Runs on the greeting thread: reads what the laptop sends while
            /// a second thread writes pictures and sound.
            public void Run()
            {
                var sender = new Thread(SendLoop) { IsBackground = true, Name = "GWMCast send" };
                sender.Start();
                try
                {
                    byte type; byte[] payload;
                    while (open && ReadMessage(stream, out type, out payload))
                    {
                        if (type == MsgPing) OfferControl(Frame(MsgPong, payload));
                        else if (type == MsgConfig) owner.ApplyConfig(Encoding.UTF8.GetString(payload));
                        else if (type == MsgBye) break;
                    }
                }
                catch (Exception) { }
                Close("lost");
            }

            void SendLoop()
            {
                var batchA = new List<Item>();
                var batchC = new List<byte[]>();
                try
                {
                    while (open)
                    {
                        wake.WaitOne(500);
                        Item v = default(Item); bool gotV;
                        lock (q)
                        {
                            while (control.Count > 0) batchC.Add(control.Dequeue());
                            while (audio.Count > 0) batchA.Add(audio.Dequeue());
                            gotV = hasVideo; v = video; hasVideo = false;
                        }
                        foreach (var c in batchC) stream.Write(c, 0, c.Length);
                        batchC.Clear();
                        foreach (var a in batchA) { stream.Write(a.Buf, 0, a.Len); owner.pool.Return(a.Buf); }
                        batchA.Clear();
                        if (gotV) { stream.Write(v.Buf, 0, v.Len); owner.pool.Return(v.Buf); }
                        if (ending) break;
                    }
                }
                catch (Exception) { }
                Close("lost");
            }

            /// Casting was switched off in the headset: say goodbye, then
            /// close. The goodbye is written by the send thread, so the
            /// caller (Unity's main thread) never waits on the network.
            public void End()
            {
                ending = true;
                OfferControl(Frame(MsgBye, Encoding.UTF8.GetBytes("{\"reason\":\"ended\"}")));
            }

            public void Close(string reason)
            {
                lock (q)
                {
                    if (!open) return;
                    open = false;
                    if (hasVideo) { owner.pool.Return(video.Buf); hasVideo = false; }
                    while (audio.Count > 0) owner.pool.Return(audio.Dequeue().Buf);
                    control.Clear();
                }
                try { Client.Close(); } catch { }
                wake.Set();
                owner.Dropped(this);
            }
        }

        // ---------- Small helpers ----------

        /// Only laptops on the same local network (or the USB cable, which
        /// arrives as loopback) may connect.
        static bool IsLocal(IPAddress a)
        {
            if (IPAddress.IsLoopback(a)) return true;
            if (a.IsIPv4MappedToIPv6) a = a.MapToIPv4();
            if (a.AddressFamily != AddressFamily.InterNetwork) return false;
            var b = a.GetAddressBytes();
            return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) ||
                   (b[0] == 192 && b[1] == 168) || (b[0] == 169 && b[1] == 254);
        }

        static string Escape(string s)
        {
            var sb = new StringBuilder();
            foreach (char c in s ?? "")
            {
                if (c == '"' || c == '\\') sb.Append('\\').Append(c);
                else if (c < 0x20) sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        // The laptop's messages are tiny, flat JSON objects; these two
        // readers are enough and avoid a JSON library on the network threads.
        static string JsonString(string json, string key)
        {
            int i = json.IndexOf("\"" + key + "\"", StringComparison.Ordinal);
            if (i < 0) return "";
            i = json.IndexOf(':', i);
            if (i < 0) return "";
            i = json.IndexOf('"', i);
            if (i < 0) return "";
            var sb = new StringBuilder();
            for (i++; i < json.Length && json[i] != '"'; i++)
            {
                if (json[i] == '\\' && i + 1 < json.Length) i++;
                sb.Append(json[i]);
            }
            return sb.Length > 64 ? sb.ToString(0, 64) : sb.ToString();
        }

        static int JsonInt(string json, string key)
        {
            int i = json.IndexOf("\"" + key + "\"", StringComparison.Ordinal);
            if (i < 0) return 0;
            i = json.IndexOf(':', i);
            if (i < 0) return 0;
            i++;
            while (i < json.Length && json[i] == ' ') i++;
            int v = 0, digits = 0;
            while (i < json.Length && json[i] >= '0' && json[i] <= '9' && digits < 6) { v = v * 10 + (json[i] - '0'); i++; digits++; }
            return v;
        }

        /// Reuses send buffers so casting does not feed the garbage collector.
        sealed class BufferPool
        {
            readonly Stack<byte[]> free = new Stack<byte[]>();
            public byte[] Rent(int min)
            {
                lock (free)
                {
                    while (free.Count > 0)
                    {
                        var b = free.Pop();
                        if (b.Length >= min) return b;
                    }
                }
                return new byte[(min + 0xFFFF) & ~0xFFFF];
            }
            public void Return(byte[] b)
            {
                if (b == null) return;
                lock (free) { if (free.Count < 24) free.Push(b); }
            }
        }
    }
}
