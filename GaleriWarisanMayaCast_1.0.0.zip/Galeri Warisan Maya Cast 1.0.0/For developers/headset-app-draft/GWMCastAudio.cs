// Galeri Warisan Maya Cast, headset side: the sound.
//
// DRAFT, not yet compiled in Unity or run on a Quest.
//
// Add this to the GameObject that holds the AudioListener, AFTER the
// listener, so OnAudioFilterRead receives the finished mix. It runs on
// Unity's audio thread and must never block or allocate.
// CHECK: a VideoPlayer whose audio output is "Direct" bypasses the listener
// and will not be heard on the laptop; route it through an AudioSource.

using UnityEngine;

namespace GWM.Cast
{
    public sealed class GWMCastAudio : MonoBehaviour
    {
        public GWMCastServer Server;
        public int Rate { get; private set; }
        public int Channels { get; private set; }
        long framesSent;

        void Awake()
        {
            Rate = AudioSettings.outputSampleRate;
            Channels = AudioSettings.speakerMode == AudioSpeakerMode.Mono ? 1 : 2;
        }

        void OnAudioFilterRead(float[] data, int channels)
        {
            var server = Server;
            if (server == null || !server.HasViewer || channels <= 0) return;
            int frames = data.Length / channels;
            int outCh = Channels;
            int bytes = frames * outCh * 2;
            var buf = server.Rent(bytes);
            int o = GWMCastServer.MediaHeader;
            for (int i = 0; i < frames; i++)
            {
                for (int c = 0; c < outCh; c++)
                {
                    // Mono in: repeat it. More than two in: keep front left/right.
                    float f = data[i * channels + (c < channels ? c : 0)];
                    if (f > 1f) f = 1f; else if (f < -1f) f = -1f;
                    short s = (short)(f * 32767f);
                    buf[o++] = (byte)s;
                    buf[o++] = (byte)(s >> 8);
                }
            }
            long pts = framesSent * 1000L / Rate;
            framesSent += frames;
            server.OfferAudio(buf, bytes, pts);
        }
    }
}
