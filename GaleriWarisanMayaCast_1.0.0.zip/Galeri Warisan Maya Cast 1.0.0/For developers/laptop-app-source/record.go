package main

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// recorder saves photos and recordings. The window encodes the recording
// and hands it over piece by piece, so a crash loses at most a second.
type recorder struct {
	photoDir, videoDir string

	mu      sync.Mutex
	f       *os.File
	id      string
	path    string
	started time.Time
	last    time.Time
	bytes   int64
}

func newRecorder(photoDir, videoDir string) *recorder {
	return &recorder{photoDir: photoDir, videoDir: videoDir}
}

func stamp() string { return time.Now().Format("2006-01-02 15.04.05") }

func uniquePath(dir, base, ext string) string {
	p := filepath.Join(dir, base+ext)
	for i := 2; ; i++ {
		if _, err := os.Stat(p); errors.Is(err, os.ErrNotExist) {
			return p
		}
		p = filepath.Join(dir, fmt.Sprintf("%s (%d)%s", base, i, ext))
	}
}

func (r *recorder) savePhoto(jpeg []byte) (string, error) {
	if len(jpeg) == 0 {
		return "", errors.New("no_picture")
	}
	if err := os.MkdirAll(r.photoDir, 0o755); err != nil {
		return "", err
	}
	p := uniquePath(r.photoDir, "Galeri Warisan Maya "+stamp(), ".jpg")
	if err := os.WriteFile(p, jpeg, 0o644); err != nil {
		return "", err
	}
	return p, nil
}

func (r *recorder) start(ext string) (id, path string, err error) {
	if ext != ".mp4" && ext != ".webm" {
		return "", "", errors.New("unsupported recording type")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.f != nil {
		return "", "", errors.New("already_recording")
	}
	if err := os.MkdirAll(r.videoDir, 0o755); err != nil {
		return "", "", err
	}
	p := uniquePath(r.videoDir, "Galeri Warisan Maya "+stamp(), ext)
	f, err := os.Create(p)
	if err != nil {
		return "", "", err
	}
	var b [8]byte
	rand.Read(b[:])
	r.f, r.id, r.path = f, hex.EncodeToString(b[:]), p
	r.started, r.last, r.bytes = time.Now(), time.Now(), 0
	return r.id, p, nil
}

func (r *recorder) write(id string, chunk []byte) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.f == nil || id != r.id {
		return errors.New("not_recording")
	}
	n, err := r.f.Write(chunk)
	r.bytes += int64(n)
	r.last = time.Now()
	return err
}

// stop closes the recording and returns where it was saved. An empty
// recording is deleted.
func (r *recorder) stop(id string) (string, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.f == nil || (id != "" && id != r.id) {
		return "", errors.New("not_recording")
	}
	err := r.f.Close()
	p, n := r.path, r.bytes
	r.f, r.id, r.path = nil, "", ""
	if n == 0 {
		os.Remove(p)
		return "", errors.New("empty_recording")
	}
	return p, err
}

func (r *recorder) info() recInfo {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.f == nil {
		return recInfo{}
	}
	return recInfo{Active: true, Seconds: int(time.Since(r.started).Seconds()), Path: r.path}
}

// reap closes a recording whose window went away without stopping it.
func (r *recorder) reap(maxSilence time.Duration) {
	r.mu.Lock()
	stale := r.f != nil && time.Since(r.last) > maxSilence
	r.mu.Unlock()
	if stale {
		r.stop("")
	}
}
