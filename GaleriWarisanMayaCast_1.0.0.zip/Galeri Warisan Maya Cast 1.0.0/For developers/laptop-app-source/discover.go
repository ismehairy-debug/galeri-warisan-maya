package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"sort"
	"sync"
	"time"

	"gwmcast/wire"
)

// found is a headset that answered a discovery probe.
type found struct {
	IP   string `json:"ip"`
	Port int    `json:"port"`
	Name string `json:"name"`
	Ver  string `json:"ver"`
	Busy bool   `json:"busy"`
}

type localNet struct {
	IP        net.IP
	Mask      net.IPMask
	Broadcast net.IP
}

// localNets lists this computer's IPv4 networks (Wi-Fi, Ethernet, hotspot).
func localNets() []localNet {
	var out []localNet
	ifs, err := net.Interfaces()
	if err != nil {
		return nil
	}
	for _, ifc := range ifs {
		if ifc.Flags&net.FlagUp == 0 || ifc.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := ifc.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			ipn, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip4 := ipn.IP.To4()
			if ip4 == nil || len(ipn.Mask) != 4 {
				continue
			}
			bc := make(net.IP, 4)
			for i := range bc {
				bc[i] = ip4[i] | ^ipn.Mask[i]
			}
			out = append(out, localNet{IP: ip4, Mask: ipn.Mask, Broadcast: bc})
		}
	}
	return out
}

func localIPs() []string {
	var out []string
	for _, n := range localNets() {
		if isPrivate(n.IP) {
			out = append(out, n.IP.String())
		}
	}
	sort.Strings(out)
	return out
}

func isPrivate(ip net.IP) bool {
	ip4 := ip.To4()
	if ip4 == nil {
		return false
	}
	switch {
	case ip4[0] == 10:
		return true
	case ip4[0] == 172 && ip4[1] >= 16 && ip4[1] <= 31:
		return true
	case ip4[0] == 192 && ip4[1] == 168:
		return true
	case ip4[0] == 169 && ip4[1] == 254:
		return true
	}
	return false
}

// probeUDP shouts on every local network and collects the headsets that
// answer within the window.
func probeUDP(window time.Duration) []found {
	nets := localNets()
	type sock struct {
		c  *net.UDPConn
		to []*net.UDPAddr
	}
	var socks []sock
	for _, n := range nets {
		c, err := net.ListenUDP("udp4", &net.UDPAddr{IP: n.IP})
		if err != nil {
			continue
		}
		socks = append(socks, sock{c: c, to: []*net.UDPAddr{
			{IP: n.Broadcast, Port: wire.DiscoveryPort},
			{IP: net.IPv4bcast, Port: wire.DiscoveryPort},
		}})
	}
	if len(socks) == 0 {
		return nil
	}
	var (
		mu  sync.Mutex
		res = map[string]found{}
		wg  sync.WaitGroup
	)
	deadline := time.Now().Add(window)
	for _, s := range socks {
		for _, to := range s.to {
			s.c.WriteToUDP([]byte(wire.ProbeText), to)
		}
		wg.Add(1)
		go func(c *net.UDPConn) {
			defer wg.Done()
			defer c.Close()
			c.SetReadDeadline(deadline)
			buf := make([]byte, 1024)
			for {
				n, from, err := c.ReadFromUDP(buf)
				if err != nil {
					// Windows reports a stray "port unreachable" from some
					// other machine as a read error; only stop when the
					// window has really closed.
					if errors.Is(err, net.ErrClosed) || !time.Now().Before(deadline) {
						return
					}
					if ne, ok := err.(net.Error); ok && ne.Timeout() {
						return
					}
					continue
				}
				var r wire.ProbeReply
				if json.Unmarshal(buf[:n], &r) != nil || r.App != wire.AppID {
					continue
				}
				port := r.Port
				if port <= 0 || port > 65535 {
					port = wire.CastPort
				}
				mu.Lock()
				res[from.IP.String()] = found{IP: from.IP.String(), Port: port, Name: r.Name, Ver: r.Ver, Busy: r.Busy}
				mu.Unlock()
			}
		}(s.c)
	}
	wg.Wait()
	out := make([]found, 0, len(res))
	for _, f := range res {
		out = append(out, f)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Busy != out[j].Busy {
			return !out[i].Busy
		}
		return out[i].IP < out[j].IP
	})
	return out
}

var (
	errBusy     = errors.New("the headset is already casting to another laptop")
	errNotCast  = errors.New("that device did not answer as a Galeri Warisan Maya headset")
	errTooNew   = errors.New("the headset app uses a newer cast version than this laptop app")
	errNoAnswer = errors.New("no answer")
)

// link is an open, greeted connection to a headset.
type link struct {
	conn  net.Conn
	r     *bufio.Reader
	hello wire.HelloMsg
	ip    string
}

// greet waits for the headset to introduce itself. It does not answer yet;
// call accept to tell the headset to start sending.
func greet(conn net.Conn, wait time.Duration) (*link, error) {
	if tc, ok := conn.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
		tc.SetKeepAlive(true)
	}
	r := bufio.NewReaderSize(conn, 256<<10)
	conn.SetReadDeadline(time.Now().Add(wait))
	typ, payload, err := wire.Read(r)
	conn.SetReadDeadline(time.Time{})
	if err != nil {
		return nil, errNoAnswer
	}
	if typ == wire.Bye {
		var b struct {
			Reason string `json:"reason"`
		}
		json.Unmarshal(payload, &b)
		if b.Reason == "busy" {
			return nil, errBusy
		}
		return nil, errNotCast
	}
	if typ != wire.Hello {
		return nil, errNotCast
	}
	var h wire.HelloMsg
	if json.Unmarshal(payload, &h) != nil || h.App != wire.AppID {
		return nil, errNotCast
	}
	if h.Proto > wire.Proto {
		return nil, errTooNew
	}
	ip, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	return &link{conn: conn, r: r, hello: h, ip: ip}, nil
}

// dialHeadset connects to one address and waits for the headset's greeting.
func dialHeadset(ctx context.Context, addr string, dialWait, helloWait time.Duration) (*link, error) {
	d := net.Dialer{Timeout: dialWait}
	conn, err := d.DialContext(ctx, "tcp4", addr)
	if err != nil {
		return nil, errNoAnswer
	}
	l, err := greet(conn, helloWait)
	if err != nil {
		conn.Close()
		return nil, err
	}
	return l, nil
}

// sweepTargets lists the addresses next to this computer on each private
// network: at most the 254 neighbours in its own /24.
func sweepTargets(includeSelf bool) []string {
	seen := map[string]bool{}
	var out []string
	for _, n := range localNets() {
		if !isPrivate(n.IP) && !includeSelf {
			continue
		}
		base := net.IPv4(n.IP[0], n.IP[1], n.IP[2], 0).To4()
		lo, hi := 1, 254
		if ones, bits := n.Mask.Size(); bits == 32 && ones > 24 {
			// Smaller than a /24 (a phone hotspot often is): stay inside it.
			size := 1 << (32 - ones)
			start := int(n.IP[3]) &^ (size - 1)
			lo, hi = start+1, start+size-2
		}
		for i := lo; i <= hi; i++ {
			ip := net.IPv4(base[0], base[1], base[2], byte(i)).To4()
			if ip.Equal(n.IP) && !includeSelf {
				continue
			}
			s := ip.String()
			if !seen[s] {
				seen[s] = true
				out = append(out, s)
			}
		}
		if len(out) > 1024 {
			break
		}
	}
	return out
}

// sweep knocks on the cast port of every neighbour and returns the first
// headset that greets back. It is the fallback for networks that do not
// carry discovery broadcasts.
func sweep(ctx context.Context, includeSelf bool) *link {
	targets := sweepTargets(includeSelf)
	if len(targets) == 0 {
		return nil
	}
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	var (
		wg     sync.WaitGroup
		once   sync.Once
		winner *link
		sem    = make(chan struct{}, 64)
	)
	for _, ip := range targets {
		if ctx.Err() != nil {
			break
		}
		sem <- struct{}{}
		wg.Add(1)
		go func(ip string) {
			defer wg.Done()
			defer func() { <-sem }()
			l, err := dialHeadset(ctx, fmt.Sprintf("%s:%d", ip, wire.CastPort), 350*time.Millisecond, 900*time.Millisecond)
			if err != nil {
				return
			}
			won := false
			once.Do(func() { winner = l; won = true; cancel() })
			if !won {
				l.conn.Close()
			}
		}(ip)
	}
	wg.Wait()
	return winner
}
