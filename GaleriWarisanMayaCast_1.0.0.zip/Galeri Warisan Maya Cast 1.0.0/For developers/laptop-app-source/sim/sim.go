// Package sim is a stand-in for the headset. It speaks the real cast
// protocol and sends a moving test picture with a bell once a second, so the
// laptop app can be tried (and tested) without a headset.
package sim

import (
	"bufio"
	"bytes"
	"context"
	_ "embed"
	"encoding/binary"
	"encoding/json"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"image/png"
	"math"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"gwmcast/wire"
)

//go:embed testcard-720.png
var card720 []byte

//go:embed testcard-540.png
var card540 []byte

//go:embed testcard-432.png
var card432 []byte

// Options configure a simulated headset.
type Options struct {
	Name      string
	Version   string
	TCPAddr   string // for example ":47800" or "127.0.0.1:0"
	Discovery bool   // answer UDP probes on wire.DiscoveryPort
	Logf      func(string, ...any)
}

// Server is a running simulated headset.
type Server struct {
	opts   Options
	ln     net.Listener
	udp    *net.UDPConn
	busy   atomic.Bool
	cancel context.CancelFunc
	wg     sync.WaitGroup

	bgMu sync.Mutex
	bgs  map[int]*image.RGBA
}

// Start begins listening. Close stops it.
func Start(opts Options) (*Server, error) {
	if opts.Logf == nil {
		opts.Logf = func(string, ...any) {}
	}
	ln, err := net.Listen("tcp4", opts.TCPAddr)
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithCancel(context.Background())
	s := &Server{opts: opts, ln: ln, cancel: cancel, bgs: map[int]*image.RGBA{}}
	if opts.Discovery {
		u, err := net.ListenUDP("udp4", &net.UDPAddr{Port: wire.DiscoveryPort})
		if err != nil {
			ln.Close()
			cancel()
			return nil, err
		}
		s.udp = u
		s.wg.Add(1)
		go s.answerProbes()
	}
	s.wg.Add(1)
	go s.accept(ctx)
	return s, nil
}

// Addr is the TCP address the simulated headset listens on.
func (s *Server) Addr() net.Addr { return s.ln.Addr() }

// Close stops the simulated headset and waits for it to finish.
func (s *Server) Close() {
	s.cancel()
	s.ln.Close()
	if s.udp != nil {
		s.udp.Close()
	}
	s.wg.Wait()
}

func (s *Server) answerProbes() {
	defer s.wg.Done()
	buf := make([]byte, 256)
	port := s.ln.Addr().(*net.TCPAddr).Port
	for {
		n, from, err := s.udp.ReadFromUDP(buf)
		if err != nil {
			return
		}
		if string(buf[:n]) != wire.ProbeText {
			continue
		}
		reply, _ := json.Marshal(wire.ProbeReply{
			App: wire.AppID, Proto: wire.Proto, Name: s.opts.Name,
			Port: port, Ver: s.opts.Version, Busy: s.busy.Load(),
		})
		s.udp.WriteToUDP(reply, from)
	}
}

func (s *Server) accept(ctx context.Context) {
	defer s.wg.Done()
	for {
		c, err := s.ln.Accept()
		if err != nil {
			return
		}
		if !s.busy.CompareAndSwap(false, true) {
			bye, _ := json.Marshal(map[string]string{"reason": "busy"})
			c.SetWriteDeadline(time.Now().Add(time.Second))
			wire.Write(c, wire.Bye, bye)
			c.Close()
			continue
		}
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			defer s.busy.Store(false)
			s.serve(ctx, c)
		}()
	}
}

type settings struct {
	height, fps, quality int
}

func clampSettings(c wire.ConfigMsg) settings {
	st := settings{height: 540, fps: 30, quality: 70}
	switch {
	case c.MaxHeight >= 720:
		st.height = 720
	case c.MaxHeight > 0 && c.MaxHeight < 540:
		st.height = 432
	}
	if c.FPS >= 5 && c.FPS <= 60 {
		st.fps = c.FPS
	}
	if c.Quality >= 20 && c.Quality <= 95 {
		st.quality = c.Quality
	}
	return st
}

const (
	audioRate   = 48000
	audioChunk  = 960 // 20 ms
	bellSeconds = 0.9
)

func (s *Server) serve(parent context.Context, c net.Conn) {
	ctx, cancel := context.WithCancel(parent)
	defer cancel()
	defer c.Close()
	go func() { <-ctx.Done(); c.Close() }()
	if tc, ok := c.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
	}
	logf := s.opts.Logf
	logf("sim: laptop connected from %s", c.RemoteAddr())

	var wmu sync.Mutex
	send := func(typ byte, payload []byte) error {
		wmu.Lock()
		defer wmu.Unlock()
		c.SetWriteDeadline(time.Now().Add(3 * time.Second))
		return wire.Write(c, typ, payload)
	}
	sendMedia := func(typ byte, pts uint64, data []byte) error {
		wmu.Lock()
		defer wmu.Unlock()
		c.SetWriteDeadline(time.Now().Add(3 * time.Second))
		return wire.WriteMedia(c, typ, pts, data)
	}

	var cur atomic.Pointer[settings]
	st0 := clampSettings(wire.ConfigMsg{})
	cur.Store(&st0)

	hello, _ := json.Marshal(wire.HelloMsg{
		App: wire.AppID, Proto: wire.Proto, Name: s.opts.Name, AppVersion: s.opts.Version,
		Width: st0.height * 16 / 9, Height: st0.height, FPS: st0.fps,
		AudioRate: audioRate, AudioCh: 2, Test: true,
	})
	if err := send(wire.Hello, hello); err != nil {
		return
	}

	r := bufio.NewReaderSize(c, 4096)
	c.SetReadDeadline(time.Now().Add(3 * time.Second))
	typ, _, err := wire.Read(r)
	if err != nil || typ != wire.ClientHello {
		logf("sim: no client hello (%v), closing", err)
		return
	}
	c.SetReadDeadline(time.Time{})

	go func() {
		defer cancel()
		for {
			typ, payload, err := wire.Read(r)
			if err != nil {
				return
			}
			switch typ {
			case wire.Ping:
				if send(wire.Pong, payload) != nil {
					return
				}
			case wire.Config:
				var cfg wire.ConfigMsg
				if json.Unmarshal(payload, &cfg) == nil {
					ns := clampSettings(cfg)
					cur.Store(&ns)
					logf("sim: picture set to %dp %d fps q%d", ns.height, ns.fps, ns.quality)
				}
			case wire.Bye:
				return
			}
		}
	}()

	start := time.Now()
	var audioSent int64 // sample frames
	nextVideo := time.Duration(0)
	pcm := make([]byte, audioChunk*4)
	var jbuf bytes.Buffer
	tick := time.NewTicker(4 * time.Millisecond)
	defer tick.Stop()

	for {
		select {
		case <-ctx.Done():
			logf("sim: laptop disconnected")
			return
		case <-tick.C:
		}
		el := time.Since(start)

		// Audio: keep the sample clock level with the wall clock.
		for float64(audioSent)/audioRate < el.Seconds() {
			fillBell(pcm, audioSent)
			pts := uint64(audioSent * 1000 / audioRate)
			if sendMedia(wire.Audio, pts, pcm) != nil {
				return
			}
			audioSent += audioChunk
		}

		if el >= nextVideo {
			st := *cur.Load()
			frame := s.render(st.height, el)
			jbuf.Reset()
			jpeg.Encode(&jbuf, frame, &jpeg.Options{Quality: st.quality})
			if sendMedia(wire.Video, uint64(el.Milliseconds()), jbuf.Bytes()) != nil {
				return
			}
			interval := time.Second / time.Duration(st.fps)
			nextVideo += interval
			if now := time.Since(start); nextVideo < now-interval {
				nextVideo = now // fell behind: skip rather than queue up
			}
		}
	}
}

// fillBell writes one chunk of stereo 16-bit PCM: a soft bell at the start
// of every second, alternating between two notes and two sides.
func fillBell(out []byte, startSample int64) {
	n := len(out) / 4
	for i := 0; i < n; i++ {
		smp := startSample + int64(i)
		sec := smp / audioRate
		t := float64(smp%audioRate) / audioRate
		var v float64
		if t < bellSeconds {
			f := 587.33 // D5
			if sec%2 == 1 {
				f = 783.99 // G5
			}
			env := math.Exp(-t * 5.5)
			attack := math.Min(1, t*400)
			v = attack * env * (0.30*math.Sin(2*math.Pi*f*t) + 0.10*math.Sin(2*math.Pi*f*2.76*t)*math.Exp(-t*9))
		}
		l, r := v, v*0.55
		if sec%2 == 1 {
			l, r = r, l
		}
		binary.LittleEndian.PutUint16(out[i*4:], uint16(int16(l*32767)))
		binary.LittleEndian.PutUint16(out[i*4+2:], uint16(int16(r*32767)))
	}
}

func (s *Server) background(h int) *image.RGBA {
	s.bgMu.Lock()
	defer s.bgMu.Unlock()
	if bg, ok := s.bgs[h]; ok {
		return bg
	}
	src := card540
	switch h {
	case 720:
		src = card720
	case 432:
		src = card432
	}
	img, err := png.Decode(bytes.NewReader(src))
	if err != nil {
		panic("embedded test card is unreadable: " + err.Error())
	}
	rgba := image.NewRGBA(img.Bounds())
	draw.Draw(rgba, rgba.Bounds(), img, image.Point{}, draw.Src)
	s.bgs[h] = rgba
	return rgba
}

var (
	gold      = color.RGBA{212, 165, 55, 255}
	ivory     = color.RGBA{243, 227, 184, 255}
	trackDark = color.RGBA{28, 6, 11, 255}
)

// render draws the moving parts over the test card: a marker that swings
// along a track and touches an end exactly when the bell sounds, and a
// running clock.
func (s *Server) render(h int, el time.Duration) *image.RGBA {
	bg := s.background(h)
	img := image.NewRGBA(bg.Bounds())
	copy(img.Pix, bg.Pix)
	u := float64(h) / 720.0
	px := func(v float64) int { return int(math.Round(v * u)) }

	// Track.
	x0, x1, y := px(460), px(1010), px(628)
	fillRect(img, x0, y-px(3), x1, y+px(3), trackDark)
	fillRect(img, x0-px(4), y-px(22), x0, y+px(22), gold)
	fillRect(img, x1, y-px(22), x1+px(4), y+px(22), gold)

	// Marker: triangle wave with a two-second period, at an end each second.
	t := el.Seconds()
	phase := math.Mod(t, 2)
	pos := phase
	if phase > 1 {
		pos = 2 - phase
	}
	r := px(16)
	cx := x0 + r + int(float64(x1-x0-2*r)*pos)
	fillDiamond(img, cx, y, r, ivory)
	// A short flash at the end that was just struck.
	if frac := math.Mod(t, 1); frac < 0.12 {
		ex := x0 - px(2)
		if int(t)%2 == 1 {
			ex = x1 + px(2)
		}
		fillDiamond(img, ex, y, px(30), gold)
	}

	// Clock mm:ss.t
	total := int(t * 10)
	digits := []int{(total / 6000) % 10, (total / 600) % 10, -1, (total / 100) % 6, (total / 10) % 10, -2, total % 10}
	dx := px(1060)
	for _, d := range digits {
		switch d {
		case -1: // colon
			fillRect(img, dx+px(4), y-px(12), dx+px(10), y-px(6), gold)
			fillRect(img, dx+px(4), y+px(6), dx+px(10), y+px(12), gold)
			dx += px(18)
		case -2: // point
			fillRect(img, dx+px(4), y+px(16), dx+px(10), y+px(22), gold)
			dx += px(18)
		default:
			sevenSeg(img, dx, y-px(24), px(22), px(48), px(5), d)
			dx += px(32)
		}
	}
	return img
}

func fillRect(img *image.RGBA, x0, y0, x1, y1 int, c color.RGBA) {
	r := image.Rect(x0, y0, x1, y1).Intersect(img.Bounds())
	if r.Empty() {
		return
	}
	draw.Draw(img, r, &image.Uniform{C: c}, image.Point{}, draw.Src)
}

func fillDiamond(img *image.RGBA, cx, cy, r int, c color.RGBA) {
	for dy := -r; dy <= r; dy++ {
		w := r - abs(dy)
		fillRect(img, cx-w, cy+dy, cx+w+1, cy+dy+1, c)
	}
}

func abs(v int) int {
	if v < 0 {
		return -v
	}
	return v
}

// segments lit for each digit: top, top-right, bottom-right, bottom,
// bottom-left, top-left, middle.
var segs = [10][7]bool{
	{true, true, true, true, true, true, false},
	{false, true, true, false, false, false, false},
	{true, true, false, true, true, false, true},
	{true, true, true, true, false, false, true},
	{false, true, true, false, false, true, true},
	{true, false, true, true, false, true, true},
	{true, false, true, true, true, true, true},
	{true, true, true, false, false, false, false},
	{true, true, true, true, true, true, true},
	{true, true, true, true, false, true, true},
}

func sevenSeg(img *image.RGBA, x, y, w, h, t, d int) {
	half := h / 2
	rects := [7]image.Rectangle{
		image.Rect(x, y, x+w, y+t),
		image.Rect(x+w-t, y, x+w, y+half),
		image.Rect(x+w-t, y+half, x+w, y+h),
		image.Rect(x, y+h-t, x+w, y+h),
		image.Rect(x, y+half, x+t, y+h),
		image.Rect(x, y, x+t, y+half),
		image.Rect(x, y+half-t/2, x+w, y+half-t/2+t),
	}
	for i, r := range rects {
		if segs[d][i] {
			fillRect(img, r.Min.X, r.Min.Y, r.Max.X, r.Max.Y, gold)
		}
	}
}
