// Package wire is the Galeri Warisan Maya Cast protocol, version 1.
//
// The headset is the server. It listens on TCP CastPort and answers UDP
// discovery probes on DiscoveryPort. Every TCP message is
//
//	[1 byte type][4 bytes little-endian payload length][payload]
//
// Headset to laptop: Hello (JSON, sent first), Video (8-byte LE millisecond
// timestamp + one JPEG), Audio (8-byte LE millisecond timestamp + signed
// 16-bit little-endian interleaved PCM), State (JSON), Pong, Bye (JSON).
// Laptop to headset: ClientHello (JSON, must arrive before any media is
// sent), Config (JSON picture settings), Ping (8 opaque bytes, echoed back).
package wire

import (
	"bufio"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
)

const (
	Proto         = 1
	CastPort      = 47800
	DiscoveryPort = 47801
	AppID         = "GWMCAST"
	ProbeText     = "GWMCAST1?"
	MaxPayload    = 8 << 20

	Hello       byte = 0x01
	Video       byte = 0x02
	Audio       byte = 0x03
	State       byte = 0x04
	Ping        byte = 0x05
	Pong        byte = 0x06
	Bye         byte = 0x07
	ClientHello byte = 0x10
	Config      byte = 0x11
	// UIStatus only travels between the receiver and its own window.
	UIStatus byte = 0x20
)

// HelloMsg is what the headset says about itself when a laptop connects.
type HelloMsg struct {
	App        string `json:"app"`
	Proto      int    `json:"proto"`
	Name       string `json:"name"`
	AppVersion string `json:"appVersion"`
	Width      int    `json:"width"`
	Height     int    `json:"height"`
	FPS        int    `json:"fps"`
	AudioRate  int    `json:"audioRate"`
	AudioCh    int    `json:"audioChannels"`
	Test       bool   `json:"test,omitempty"`
}

// ClientHelloMsg introduces the laptop.
type ClientHelloMsg struct {
	Proto int    `json:"proto"`
	Name  string `json:"name"`
	App   string `json:"app"`
}

// ConfigMsg asks the headset for a picture size, rate and JPEG quality.
type ConfigMsg struct {
	MaxHeight int `json:"maxHeight"`
	FPS       int `json:"fps"`
	Quality   int `json:"quality"`
}

// ProbeReply is the UDP answer to ProbeText.
type ProbeReply struct {
	App   string `json:"app"`
	Proto int    `json:"proto"`
	Name  string `json:"name"`
	Port  int    `json:"port"`
	Ver   string `json:"ver"`
	Busy  bool   `json:"busy"`
}

// Write sends one message with a single Write call so header and payload
// are never split across packets.
func Write(w io.Writer, typ byte, payload []byte) error {
	if len(payload) > MaxPayload {
		return fmt.Errorf("payload too large: %d", len(payload))
	}
	buf := make([]byte, 5+len(payload))
	buf[0] = typ
	binary.LittleEndian.PutUint32(buf[1:5], uint32(len(payload)))
	copy(buf[5:], payload)
	_, err := w.Write(buf)
	return err
}

// WriteMedia sends a Video or Audio message: timestamp then data.
func WriteMedia(w io.Writer, typ byte, ptsMillis uint64, data []byte) error {
	if len(data)+8 > MaxPayload {
		return fmt.Errorf("payload too large: %d", len(data))
	}
	buf := make([]byte, 5+8+len(data))
	buf[0] = typ
	binary.LittleEndian.PutUint32(buf[1:5], uint32(8+len(data)))
	binary.LittleEndian.PutUint64(buf[5:13], ptsMillis)
	copy(buf[13:], data)
	_, err := w.Write(buf)
	return err
}

// ErrTooLarge is returned when a peer announces an oversized payload.
var ErrTooLarge = errors.New("message larger than the protocol allows")

// Read returns the next message. The payload is freshly allocated.
func Read(r *bufio.Reader) (byte, []byte, error) {
	var hdr [5]byte
	if _, err := io.ReadFull(r, hdr[:]); err != nil {
		return 0, nil, err
	}
	n := binary.LittleEndian.Uint32(hdr[1:5])
	if n > MaxPayload {
		return 0, nil, ErrTooLarge
	}
	payload := make([]byte, n)
	if _, err := io.ReadFull(r, payload); err != nil {
		return 0, nil, err
	}
	return hdr[0], payload, nil
}

// ReadFramed returns the next message with its 5-byte header still attached
// (framed[5:] is the payload), so it can be forwarded without copying.
func ReadFramed(r *bufio.Reader) (typ byte, framed []byte, err error) {
	var hdr [5]byte
	if _, err := io.ReadFull(r, hdr[:]); err != nil {
		return 0, nil, err
	}
	n := binary.LittleEndian.Uint32(hdr[1:5])
	if n > MaxPayload {
		return 0, nil, ErrTooLarge
	}
	framed = make([]byte, 5+int(n))
	copy(framed, hdr[:])
	if _, err := io.ReadFull(r, framed[5:]); err != nil {
		return 0, nil, err
	}
	return hdr[0], framed, nil
}

// Frame wraps a payload in a header.
func Frame(typ byte, payload []byte) []byte {
	buf := make([]byte, 5+len(payload))
	buf[0] = typ
	binary.LittleEndian.PutUint32(buf[1:5], uint32(len(payload)))
	copy(buf[5:], payload)
	return buf
}
