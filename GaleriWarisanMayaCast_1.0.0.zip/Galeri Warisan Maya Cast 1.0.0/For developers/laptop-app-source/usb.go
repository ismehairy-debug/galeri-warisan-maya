package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"gwmcast/wire"
)

// findADB looks for the Android debug bridge, which carries the cast over a
// USB cable. It ships with Unity's Android support, SideQuest and Meta
// Quest Developer Hub, so a laptop that installed the headset app has it.
func findADB() string {
	name := "adb" + exeSuffix
	if p, err := exec.LookPath(name); err == nil {
		return p
	}
	var candidates []string
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		candidates = append(candidates, filepath.Join(dir, name), filepath.Join(dir, "platform-tools", name))
	}
	candidates = append(candidates, adbCandidates()...)
	for _, c := range candidates {
		matches, _ := filepath.Glob(c)
		for _, m := range matches {
			if st, err := os.Stat(m); err == nil && !st.IsDir() {
				return m
			}
		}
	}
	return ""
}

func runADB(ctx context.Context, adb string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, adb, args...)
	hideWindow(cmd)
	out, err := cmd.CombinedOutput()
	return string(out), err
}

// usbForward makes this computer's cast port lead down the cable to the
// headset. It returns "" on success or a problem code for the window.
func usbForward(ctx context.Context) string {
	adb := findADB()
	if adb == "" {
		return "usb_no_adb"
	}
	out, err := runADB(ctx, adb, "devices")
	if err != nil {
		log.Printf("adb devices failed: %v: %s", err, out)
		return "usb_error"
	}
	ready, unauthorized := 0, 0
	for _, line := range strings.Split(out, "\n") {
		f := strings.Fields(line)
		if len(f) != 2 {
			continue
		}
		switch f[1] {
		case "device":
			ready++
		case "unauthorized":
			unauthorized++
		}
	}
	switch {
	case ready == 0 && unauthorized > 0:
		return "usb_unauthorized"
	case ready == 0:
		return "usb_no_device"
	case ready > 1:
		return "usb_many_devices"
	}
	port := fmt.Sprintf("tcp:%d", wire.CastPort)
	if out, err := runADB(ctx, adb, "forward", port, port); err != nil {
		log.Printf("adb forward failed: %v: %s", err, out)
		return "usb_error"
	}
	return ""
}

func usbUnforward() {
	if adb := findADB(); adb != "" {
		runADB(context.Background(), adb, "forward", "--remove", fmt.Sprintf("tcp:%d", wire.CastPort))
	}
}
