// Galeri Warisan Maya Cast shows what a visitor sees in the VR headset on a
// laptop, live. The headset app (version 1.1.0 or later) sends the picture
// and sound over the local network or a USB cable; this program finds the
// headset, receives the stream and displays it in a window of its own.
package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const version = "1.0.0"

type instance struct {
	Port  int    `json:"port"`
	Token string `json:"token"`
	PID   int    `json:"pid"`
}

func main() {
	noBrowser := flag.Bool("no-browser", false, "do not open a window (the address is printed instead)")
	port := flag.Int("port", 0, "local port for the app's own window (0 picks one)")
	mode := flag.String("mode", "auto", "how to find the headset: auto, usb, manual or test")
	ip := flag.String("ip", "", "headset address for -mode manual")
	grab := flag.String("grab", "", "save one picture from the headset to this file and exit (for checking a setup)")
	includeSelf := flag.Bool("test-include-self", false, "let the neighbour search find a headset on this computer (tests only)")
	flag.Parse()

	dir := dataDir()
	os.MkdirAll(dir, 0o755)
	logTo(filepath.Join(dir, "cast.log"))
	log.Printf("Galeri Warisan Maya Cast %s starting", version)

	cfg := loadConfig(dir)
	rec := newRecorder(photosDir(), videosDir())
	h := newHub()
	m := newManager(h, cfg, rec)
	m.includeSelf = *includeSelf
	if *mode != "auto" {
		if err := m.setMode(*mode, *ip); err != nil {
			fmt.Fprintln(os.Stderr, "bad -mode or -ip:", err)
			os.Exit(2)
		}
	}

	ctx, cancel := context.WithCancel(context.Background())
	var quitOnce sync.Once
	quit := func() { quitOnce.Do(cancel) }
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	go func() { <-sig; quit() }()

	if *grab != "" {
		go m.run(ctx)
		os.Exit(grabOne(ctx, m, h, *grab))
	}

	instFile := filepath.Join(dir, "instance.json")
	if !*noBrowser {
		if prev := readInstance(instFile); prev != nil && alive(prev) {
			log.Printf("already running; showing its window again")
			launch(urlFor(prev.Port, prev.Token), filepath.Join(dir, "window"))
			return
		}
	}

	ln, err := net.Listen("tcp4", fmt.Sprintf("127.0.0.1:%d", *port))
	if err != nil {
		log.Fatalf("cannot open a local port: %v", err)
	}
	actual := ln.Addr().(*net.TCPAddr).Port
	var tb [16]byte
	rand.Read(tb[:])
	token := hex.EncodeToString(tb[:])
	if t := os.Getenv("GWMCAST_TOKEN"); t != "" {
		token = t // tests
	}

	srv := &server{m: m, hub: h, cfg: cfg, rec: rec, token: token, port: actual, quit: quit}
	httpSrv := &http.Server{Handler: srv.handler(), ReadHeaderTimeout: 5 * time.Second}
	go func() {
		if err := httpSrv.Serve(ln); err != nil && err != http.ErrServerClosed {
			log.Printf("local server stopped: %v", err)
			quit()
		}
	}()
	go m.run(ctx)

	url := urlFor(actual, token)
	if *noBrowser {
		fmt.Println(url)
	} else {
		b, _ := json.Marshal(instance{Port: actual, Token: token, PID: os.Getpid()})
		os.WriteFile(instFile, b, 0o600)
		defer os.Remove(instFile)
		go watchWindow(ctx, quit, h, url, filepath.Join(dir, "window"))
	}

	// Housekeeping: close a recording whose window vanished.
	go func() {
		t := time.NewTicker(2 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				rec.reap(10 * time.Second)
			}
		}
	}()

	<-ctx.Done()
	log.Printf("closing")
	rec.stop("")
	sctx, scancel := context.WithTimeout(context.Background(), time.Second)
	httpSrv.Shutdown(sctx)
	scancel()
	m.stopUSB()
}

func urlFor(port int, token string) string {
	return fmt.Sprintf("http://127.0.0.1:%d/?t=%s", port, token)
}

func logTo(path string) {
	if st, err := os.Stat(path); err == nil && st.Size() > 1<<20 {
		os.Rename(path, path+".old")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	log.SetOutput(io.MultiWriter(f, os.Stderr))
	log.SetFlags(log.LstdFlags)
}

func readInstance(path string) *instance {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var in instance
	if json.Unmarshal(b, &in) != nil || in.Port == 0 || in.Token == "" {
		return nil
	}
	return &in
}

func alive(in *instance) bool {
	c := http.Client{Timeout: 700 * time.Millisecond}
	resp, err := c.Get(fmt.Sprintf("http://127.0.0.1:%d/api/ping?t=%s", in.Port, in.Token))
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	var v struct {
		App string `json:"app"`
	}
	return resp.StatusCode == 200 && json.NewDecoder(resp.Body).Decode(&v) == nil && v.App == "gwmcast"
}

// launch opens the app's window: Edge or Chrome in "app" mode (a plain
// window, no tabs or address bar) with its own small profile folder, or the
// default browser if neither is installed.
func launch(url, profileDir string) *exec.Cmd {
	for _, b := range browsers() {
		if st, err := os.Stat(b); err != nil || st.IsDir() {
			continue
		}
		args := []string{
			"--app=" + url,
			"--user-data-dir=" + profileDir,
			"--no-first-run",
			"--no-default-browser-check",
			"--autoplay-policy=no-user-gesture-required",
			"--disable-backgrounding-occluded-windows",
			"--disable-renderer-backgrounding",
			"--disable-background-mode",
			"--hide-crash-restore-bubble",
			"--window-size=1280,780",
		}
		// Extra switches for troubleshooting, for example on a machine
		// where the browser needs a special flag to start.
		args = append(args, strings.Fields(os.Getenv("GWMCAST_BROWSER_FLAGS"))...)
		cmd := exec.Command(b, args...)
		if err := cmd.Start(); err != nil {
			log.Printf("could not start %s: %v", b, err)
			continue
		}
		log.Printf("window opened with %s", b)
		return cmd
	}
	if err := openDefault(url); err != nil {
		log.Printf("could not open the default browser: %v", err)
	} else {
		log.Printf("window opened in the default browser")
	}
	return nil
}

// watchWindow opens the window and ends the program when it is closed.
// "Closed" is judged by the window's own connection to this program, not by
// the browser process: browsers hand over to helper processes and may linger
// in the background, but the connection ends the moment the window does.
func watchWindow(ctx context.Context, quit func(), h *hub, url, profileDir string) {
	started := time.Now()
	cmd := launch(url, profileDir)
	if cmd != nil {
		go cmd.Wait() // reap it; its exit means nothing by itself
	}
	triedDefault := cmd == nil
	t := time.NewTicker(500 * time.Millisecond)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		ever, gone := h.idle()
		switch {
		case ever && gone > 4*time.Second:
			log.Printf("window closed")
			quit()
			return
		case !ever && !triedDefault && time.Since(started) > 20*time.Second:
			log.Printf("no window appeared; trying the default browser")
			triedDefault = true
			openDefault(url)
		case !ever && time.Since(started) > 2*time.Minute:
			log.Printf("no window ever connected; giving up")
			quit()
			return
		}
	}
}

// grabOne waits for the headset, saves one picture and reports what it saw.
func grabOne(ctx context.Context, m *manager, h *hub, path string) int {
	deadline := time.Now().Add(30 * time.Second)
	var liveSince time.Time
	for time.Now().Before(deadline) && ctx.Err() == nil {
		time.Sleep(200 * time.Millisecond)
		st := m.snapshotStatus()
		if st.State != "live" || h.latestJPEG() == nil {
			liveSince = time.Time{}
			continue
		}
		if liveSince.IsZero() {
			liveSince = time.Now()
		}
		if time.Since(liveSince) < 3*time.Second {
			continue // let the statistics settle
		}
		if err := os.WriteFile(path, h.latestJPEG(), 0o644); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		st = m.snapshotStatus()
		b, _ := json.MarshalIndent(st, "", "  ")
		os.WriteFile(path+".json", b, 0o644)
		fmt.Println(string(b))
		return 0
	}
	st := m.snapshotStatus()
	b, _ := json.MarshalIndent(st, "", "  ")
	os.WriteFile(path+".json", b, 0o644)
	fmt.Fprintln(os.Stderr, "no picture arrived within 30 seconds")
	fmt.Println(string(b))
	return 1
}
