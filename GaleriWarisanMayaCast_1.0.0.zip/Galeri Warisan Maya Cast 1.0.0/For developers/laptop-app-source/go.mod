module gwmcast

go 1.22
