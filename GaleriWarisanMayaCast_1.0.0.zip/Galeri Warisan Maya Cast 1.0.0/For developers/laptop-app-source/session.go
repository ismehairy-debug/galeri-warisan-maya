package main

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"os"
	"sync"
	"time"

	"gwmcast/sim"
	"gwmcast/wire"
)

// Picture presets the laptop can ask the headset for.
var presets = map[string]wire.ConfigMsg{
	"sharp":    {MaxHeight: 720, FPS: 30, Quality: 78},
	"balanced": {MaxHeight: 540, FPS: 30, Quality: 70},
	"light":    {MaxHeight: 432, FPS: 20, Quality: 60},
}

type headsetInfo struct {
	Name       string `json:"name"`
	IP         string `json:"ip"`
	AppVersion string `json:"appVersion"`
	Test       bool   `json:"test"`
	AudioRate  int    `json:"audioRate"`
	AudioCh    int    `json:"audioChannels"`
}

type statsInfo struct {
	FPS    float64 `json:"fps"`
	Mbps   float64 `json:"mbps"`
	PingMs int     `json:"pingMs"`
}

type recInfo struct {
	Active  bool   `json:"active"`
	Seconds int    `json:"seconds"`
	Path    string `json:"path"`
}

// status is everything the window needs to draw itself.
type status struct {
	Version   string          `json:"version"`
	State     string          `json:"state"` // searching | live
	Mode      string          `json:"mode"`  // auto | usb | manual | test
	ManualIP  string          `json:"manualIp"`
	Problem   string          `json:"problem"` // a code the window turns into words
	Headset   *headsetInfo    `json:"headset"`
	HeadState json.RawMessage `json:"headsetState,omitempty"`
	Stats     statsInfo       `json:"stats"`
	Recording recInfo         `json:"recording"`
	Quality   string          `json:"quality"`
	Found     []found         `json:"found"`
	LaptopIPs []string        `json:"laptopIps"`
	Session   int             `json:"session"` // goes up each time a headset connects
}

type manager struct {
	hub *hub
	cfg *config
	rec *recorder

	includeSelf bool // tests only: let the sweep find a headset on this computer

	mu        sync.Mutex
	mode      string
	manualIP  string
	quality   string
	gen       int
	state     string
	problem   string
	headset   *headsetInfo
	headState json.RawMessage
	stats     statsInfo
	found     []found
	session   int
	link      *link
	wmu       sync.Mutex // serialises writes to the headset
	wake      chan struct{}
	demo      *sim.Server
	usbActive bool

	frames, bytes int // counted since the last stats tick
}

func newManager(h *hub, cfg *config, rec *recorder) *manager {
	m := &manager{
		hub: h, cfg: cfg, rec: rec,
		mode: "auto", quality: cfg.get().Quality, state: "searching",
		wake: make(chan struct{}, 1),
	}
	if _, ok := presets[m.quality]; !ok {
		m.quality = "balanced"
	}
	return m
}

func (m *manager) snapshotStatus() status {
	m.mu.Lock()
	defer m.mu.Unlock()
	return status{
		Version: version, State: m.state, Mode: m.mode, ManualIP: m.manualIP,
		Problem: m.problem, Headset: m.headset, HeadState: m.headState, Stats: m.stats,
		Recording: m.rec.info(), Quality: m.quality, Found: m.found,
		LaptopIPs: localIPs(), Session: m.session,
	}
}

func (m *manager) pushStatus() {
	b, err := json.Marshal(m.snapshotStatus())
	if err != nil {
		return
	}
	m.hub.status(wire.Frame(wire.UIStatus, b))
}

func (m *manager) setProblem(code string) {
	m.mu.Lock()
	changed := m.problem != code
	m.problem = code
	m.mu.Unlock()
	if changed {
		m.pushStatus()
	}
}

// setMode switches how the app looks for the headset and drops any current
// connection so the new mode takes effect at once.
func (m *manager) setMode(mode, ip string) error {
	switch mode {
	case "auto", "usb", "test":
		ip = ""
	case "manual":
		parsed := net.ParseIP(ip)
		if parsed == nil || parsed.To4() == nil {
			return errors.New("bad_ip")
		}
		ip = parsed.To4().String()
	default:
		return errors.New("unknown mode")
	}
	m.mu.Lock()
	m.mode, m.manualIP = mode, ip
	m.gen++
	m.problem = ""
	l := m.link
	m.mu.Unlock()
	if l != nil {
		l.conn.Close()
	}
	select {
	case m.wake <- struct{}{}:
	default:
	}
	m.pushStatus()
	return nil
}

func (m *manager) setQuality(q string) error {
	cfgMsg, ok := presets[q]
	if !ok {
		return errors.New("unknown quality")
	}
	m.mu.Lock()
	m.quality = q
	l := m.link
	m.mu.Unlock()
	m.cfg.update(func(c *configData) { c.Quality = q })
	if l != nil {
		b, _ := json.Marshal(cfgMsg)
		m.send(l, wire.Config, b)
	}
	m.pushStatus()
	return nil
}

func (m *manager) send(l *link, typ byte, payload []byte) error {
	m.wmu.Lock()
	defer m.wmu.Unlock()
	l.conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
	return wire.Write(l.conn, typ, payload)
}

func (m *manager) current() (mode, ip string, gen int) {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.mode, m.manualIP, m.gen
}

func (m *manager) stale(gen int) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.gen != gen
}

// pause waits, but returns early when the mode changes or the app quits.
func (m *manager) pause(ctx context.Context, d time.Duration) {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
	case <-m.wake:
	case <-t.C:
	}
}

func (m *manager) run(ctx context.Context) {
	go m.statsLoop(ctx)
	for ctx.Err() == nil {
		mode, ip, gen := m.current()
		if mode != "test" {
			m.stopDemo()
		}
		if mode != "usb" {
			m.stopUSB()
		}
		var l *link
		switch mode {
		case "test":
			l = m.connectDemo(ctx)
		case "usb":
			l = m.connectUSB(ctx)
		case "manual":
			var err error
			l, err = dialHeadset(ctx, fmt.Sprintf("%s:%d", ip, wire.CastPort), 1500*time.Millisecond, 2*time.Second)
			m.setProblem(problemFor(err, "manual_no_answer"))
		default:
			l = m.discover(ctx, gen)
		}
		if l == nil {
			m.pause(ctx, time.Second)
			continue
		}
		if m.stale(gen) || ctx.Err() != nil {
			l.conn.Close()
			continue
		}
		m.runSession(ctx, l, mode)
		m.pause(ctx, 400*time.Millisecond)
	}
	m.stopDemo()
	m.stopUSB()
}

func problemFor(err error, fallback string) string {
	switch {
	case err == nil:
		return ""
	case errors.Is(err, errBusy):
		return "busy"
	case errors.Is(err, errTooNew):
		return "too_new"
	case errors.Is(err, errNotCast):
		return "not_cast"
	}
	return fallback
}

func (m *manager) connectDemo(ctx context.Context) *link {
	m.mu.Lock()
	d := m.demo
	m.mu.Unlock()
	if d == nil {
		var err error
		d, err = sim.Start(sim.Options{Name: "Test picture", Version: version, TCPAddr: "127.0.0.1:0", Logf: log.Printf})
		if err != nil {
			log.Printf("test picture could not start: %v", err)
			m.setProblem("test_failed")
			return nil
		}
		m.mu.Lock()
		m.demo = d
		m.mu.Unlock()
	}
	l, err := dialHeadset(ctx, d.Addr().String(), time.Second, 2*time.Second)
	if err != nil {
		m.setProblem("test_failed")
		return nil
	}
	m.setProblem("")
	return l
}

func (m *manager) stopDemo() {
	m.mu.Lock()
	d := m.demo
	m.demo = nil
	m.mu.Unlock()
	if d != nil {
		d.Close()
	}
}

func (m *manager) connectUSB(ctx context.Context) *link {
	code := usbForward(ctx)
	if code != "" {
		m.setProblem(code)
		m.pause(ctx, 1500*time.Millisecond)
		return nil
	}
	m.mu.Lock()
	m.usbActive = true
	m.mu.Unlock()
	l, err := dialHeadset(ctx, fmt.Sprintf("127.0.0.1:%d", wire.CastPort), time.Second, 2*time.Second)
	m.setProblem(problemFor(err, "usb_app_not_casting"))
	return l
}

func (m *manager) stopUSB() {
	m.mu.Lock()
	active := m.usbActive
	m.usbActive = false
	m.mu.Unlock()
	if active {
		usbUnforward()
	}
}

// discover looks for a headset on the local network until it finds one or
// the mode changes. Order: the address that worked last time, a broadcast
// probe, then (now and again) a knock on each neighbour.
func (m *manager) discover(ctx context.Context, gen int) *link {
	for round := 1; ctx.Err() == nil && !m.stale(gen); round++ {
		var lastErr error
		if last := m.cfg.get().LastIP; last != "" && round%2 == 1 {
			if l, err := dialHeadset(ctx, fmt.Sprintf("%s:%d", last, wire.CastPort), 400*time.Millisecond, time.Second); err == nil {
				return l
			} else if !errors.Is(err, errNoAnswer) {
				lastErr = err
			}
		}
		fs := probeUDP(700 * time.Millisecond)
		m.mu.Lock()
		m.found = fs
		m.mu.Unlock()
		for _, f := range fs {
			if m.stale(gen) {
				return nil
			}
			l, err := dialHeadset(ctx, fmt.Sprintf("%s:%d", f.IP, f.Port), 800*time.Millisecond, 1500*time.Millisecond)
			if err == nil {
				return l
			}
			lastErr = err
		}
		// Knocking on every neighbour is the heavier search, so it runs
		// early once and then only now and again (about every ten seconds).
		if len(fs) == 0 && (round == 3 || round%8 == 0) && !m.stale(gen) {
			if l := sweep(ctx, m.includeSelf); l != nil {
				return l
			}
		}
		m.setProblem(problemFor(lastErr, ""))
		m.pushStatus()
		m.pause(ctx, 300*time.Millisecond)
	}
	return nil
}

func (m *manager) runSession(ctx context.Context, l *link, mode string) {
	defer l.conn.Close()
	host, _ := os.Hostname()
	ch, _ := json.Marshal(wire.ClientHelloMsg{Proto: wire.Proto, Name: host, App: "GaleriWarisanMayaCast/" + version})
	m.mu.Lock()
	q := m.quality
	m.mu.Unlock()
	cfgMsg, _ := json.Marshal(presets[q])
	if m.send(l, wire.ClientHello, ch) != nil || m.send(l, wire.Config, cfgMsg) != nil {
		return
	}

	m.mu.Lock()
	m.link = l
	m.state = "live"
	m.problem = ""
	m.session++
	m.headState = nil
	m.headset = &headsetInfo{
		Name: l.hello.Name, IP: l.ip, AppVersion: l.hello.AppVersion, Test: l.hello.Test,
		AudioRate: l.hello.AudioRate, AudioCh: l.hello.AudioCh,
	}
	m.stats = statsInfo{PingMs: -1}
	m.mu.Unlock()
	if mode == "auto" || mode == "manual" {
		m.cfg.update(func(c *configData) { c.LastIP = l.ip })
	}
	log.Printf("connected to %q at %s (app %s)", l.hello.Name, l.ip, l.hello.AppVersion)
	m.pushStatus()

	done := make(chan struct{})
	go func() { // keep-alive and round-trip time
		t := time.NewTicker(time.Second)
		defer t.Stop()
		var b [8]byte
		for {
			select {
			case <-done:
				return
			case <-ctx.Done():
				l.conn.Close()
				return
			case <-t.C:
				binary.LittleEndian.PutUint64(b[:], uint64(time.Now().UnixMilli()))
				if m.send(l, wire.Ping, b[:]) != nil {
					l.conn.Close()
					return
				}
			}
		}
	}()

	reason := "lost"
	for {
		l.conn.SetReadDeadline(time.Now().Add(5 * time.Second))
		typ, framed, err := wire.ReadFramed(l.r)
		if err != nil {
			break
		}
		payload := framed[5:]
		switch typ {
		case wire.Video:
			if len(payload) < 10 {
				continue
			}
			m.mu.Lock()
			m.frames++
			m.bytes += len(framed)
			m.mu.Unlock()
			m.hub.video(framed)
		case wire.Audio:
			if len(payload) < 8 {
				continue
			}
			m.mu.Lock()
			m.bytes += len(framed)
			m.mu.Unlock()
			m.hub.audio(framed)
		case wire.Pong:
			if len(payload) == 8 {
				rtt := time.Now().UnixMilli() - int64(binary.LittleEndian.Uint64(payload))
				m.mu.Lock()
				if rtt >= 0 && rtt < 60000 {
					m.stats.PingMs = int(rtt)
				}
				m.mu.Unlock()
			}
		case wire.State:
			if json.Valid(payload) {
				m.mu.Lock()
				m.headState = append(json.RawMessage(nil), payload...)
				m.mu.Unlock()
				m.pushStatus()
			}
		case wire.Bye:
			reason = "ended"
		}
		if reason == "ended" {
			break
		}
	}
	close(done)

	m.mu.Lock()
	m.link = nil
	m.state = "searching"
	m.headset = nil
	m.headState = nil
	m.stats = statsInfo{}
	m.frames, m.bytes = 0, 0
	m.mu.Unlock()
	m.hub.clearVideo()
	log.Printf("headset connection %s", reason)
	m.pushStatus()
}

// statsLoop publishes frames per second and bitrate once a second.
func (m *manager) statsLoop(ctx context.Context) {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	last := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		case now := <-t.C:
			dt := now.Sub(last).Seconds()
			last = now
			if dt <= 0 {
				continue
			}
			m.mu.Lock()
			m.stats.FPS = float64(m.frames) / dt
			m.stats.Mbps = float64(m.bytes) * 8 / 1e6 / dt
			m.frames, m.bytes = 0, 0
			m.mu.Unlock()
			m.pushStatus()
		}
	}
}
