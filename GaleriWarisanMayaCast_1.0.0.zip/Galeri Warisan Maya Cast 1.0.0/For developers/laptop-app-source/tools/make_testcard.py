"""Render the built-in test picture backgrounds (one per stream height)."""
import sys
from PIL import Image, ImageDraw, ImageFont

FONT = sys.argv[1]
OUT = sys.argv[2]

MAROON_DEEP = (43, 11, 18)
MAROON = (92, 18, 32)
GOLD = (212, 165, 55)
IVORY = (243, 227, 184)


def font(size, weight=500):
    f = ImageFont.truetype(FONT, size)
    try:
        f.set_variation_by_axes([weight])
    except Exception:
        pass
    return f


def pucuk_rebung(d, x0, y0, w, h, n, colour, gap):
    """A row of nested triangles, the bamboo-shoot border of a songket."""
    step = w / n
    for i in range(n):
        ax = x0 + i * step
        for k in range(4):
            inset = k * gap
            if step / 2 - inset <= 1:
                break
            pts = [
                (ax + inset, y0 + h),
                (ax + step / 2, y0 + inset * 2 * h / step),
                (ax + step - inset, y0 + h),
            ]
            if k % 2 == 0:
                d.polygon(pts, fill=colour)
            else:
                d.polygon(pts, fill=MAROON_DEEP)


def diamonds(d, x0, y0, x1, y1, cell, colour):
    """Scattered small diamonds, like the field of a songket."""
    r = cell * 0.09
    row = 0
    y = y0
    while y < y1:
        x = x0 + (cell / 2 if row % 2 else 0)
        while x < x1:
            d.polygon([(x, y - r), (x + r, y), (x, y + r), (x - r, y)], fill=colour)
            x += cell
        y += cell / 2
        row += 1


def render(h):
    S = 2  # supersample
    w = h * 16 // 9
    W, H = w * S, h * S
    u = H / 720.0
    img = Image.new("RGB", (W, H), MAROON_DEEP)
    d = ImageDraw.Draw(img)

    # Field of small diamonds on the right two thirds.
    diamonds(d, int(W * 0.36), int(60 * u), W, H - int(60 * u), 56 * u, (74, 22, 30))

    # Kepala kain: the decorated head panel down the left side.
    panel_w = int(W * 0.30)
    d.rectangle([0, 0, panel_w, H], fill=MAROON)
    band = int(64 * u)
    pucuk_rebung(d, 0, H / 2 - band * 4.2, panel_w, band * 4, 3, GOLD, 15 * u)
    # mirrored row pointing down
    tmp = Image.new("RGB", (panel_w, band * 4), MAROON)
    td = ImageDraw.Draw(tmp)
    pucuk_rebung(td, 0, 0, panel_w, band * 4, 3, GOLD, 15 * u)
    # repaint the gaps in the panel colour before flipping
    img.paste(tmp.transpose(Image.FLIP_TOP_BOTTOM), (0, int(H / 2 + band * 0.2)))
    for yy in (H / 2 - band * 4.2 - 20 * u, H / 2 + band * 4.2 + 14 * u):
        d.rectangle([0, yy, panel_w, yy + 6 * u], fill=GOLD)
    d.rectangle([panel_w, 0, panel_w + 5 * u, H], fill=GOLD)

    # Words.
    tx = int(W * 0.36)
    d.text((tx, 150 * u), "Test picture", font=font(int(92 * u), 600), fill=IVORY)
    d.text((tx, 262 * u), "Gambar ujian", font=font(int(46 * u), 400), fill=GOLD)
    body = font(int(30 * u), 400)
    d.text((tx, 372 * u), "This is not the headset. It shows that the", font=body, fill=IVORY)
    d.text((tx, 414 * u), "laptop app can show a picture and play sound.", font=body, fill=IVORY)
    small = font(int(24 * u), 400)
    d.text((tx, 478 * u), "Ini bukan paparan headset. Ia menunjukkan aplikasi", font=small, fill=(214, 190, 150))
    d.text((tx, 512 * u), "komputer riba boleh memaparkan gambar dan bunyi.", font=small, fill=(214, 190, 150))

    img = img.resize((w, h), Image.LANCZOS)
    img.save(f"{OUT}/testcard-{h}.png", optimize=True)
    print(h, w)


for h in (720, 540, 432):
    render(h)
