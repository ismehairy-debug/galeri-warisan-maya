"""Write rsrc_windows_amd64.syso: a COFF object holding the program's icon,
so GaleriWarisanMayaCast.exe shows it in File Explorer and on the taskbar.
Only RT_ICON and RT_GROUP_ICON are written."""
import io, struct, sys
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
master = Image.open(src).convert("RGBA")

def dib(size):
    """A classic icon image: 32-bit colour rows bottom-up, then the 1-bit
    transparency mask Windows expects after them."""
    im = master.resize((size, size), Image.LANCZOS)
    px = im.load()
    head = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0, 0, 0, 0, 0, 0)
    colour = bytearray()
    mask = bytearray()
    row_bytes = ((size + 31) // 32) * 4
    for y in range(size - 1, -1, -1):
        bits = bytearray(row_bytes)
        for x in range(size):
            r, g, b, a = px[x, y]
            colour += bytes((b, g, r, a))
            if a == 0:
                bits[x // 8] |= 0x80 >> (x % 8)
        mask += bits
    return head + bytes(colour) + bytes(mask)

def png(size):
    buf = io.BytesIO()
    master.resize((size, size), Image.LANCZOS).save(buf, format="PNG", optimize=True)
    return buf.getvalue()

images = {s: (dib(s), 1, 32) for s in (16, 24, 32, 48)}
images[256] = (png(256), 1, 32)
order = [16, 24, 32, 48, 256]

LANG = 0x0409
icons = [(i + 1, images[s][0]) for i, s in enumerate(order)]
grp = struct.pack("<HHH", 0, 1, len(order))
for i, s in enumerate(order):
    data, planes, bpp = images[s]
    grp += struct.pack("<BBBBHHIH", s if s < 256 else 0, s if s < 256 else 0, 0, 0, 1, 32, len(data), i + 1)

# Resource tree: type -> id -> language -> data.
tree = [(3, [(rid, data) for rid, data in icons]), (14, [(1, grp)])]

def directory(n_ids):
    return struct.pack("<IIHHHH", 0, 0, 0, 0, 0, n_ids)

# Lay out: all directories first, then data entries, then the data itself.
root_size = 16 + 8 * len(tree)
type_dirs_size = sum(16 + 8 * len(items) for _, items in tree)
n_leaves = sum(len(items) for _, items in tree)
lang_dirs_size = n_leaves * (16 + 8)
entries_off = root_size + type_dirs_size + lang_dirs_size
data_off = entries_off + n_leaves * 16

blob = bytearray()
relocs = []
root = bytearray(directory(len(tree)))
type_dirs = bytearray()
lang_dirs = bytearray()
entries = bytearray()
payload = bytearray()
type_off = root_size
lang_off = root_size + type_dirs_size
leaf = 0
for rtype, items in tree:
    root += struct.pack("<II", rtype, 0x80000000 | (type_off + len(type_dirs)))
    td = bytearray(directory(len(items)))
    for rid, data in items:
        td += struct.pack("<II", rid, 0x80000000 | (lang_off + len(lang_dirs)))
        entry_at = entries_off + leaf * 16
        lang_dirs += directory(1) + struct.pack("<II", LANG, entry_at)
        while len(payload) % 8:
            payload += b"\0"
        relocs.append(entry_at)                     # the data address needs fixing up
        entries += struct.pack("<IIII", data_off + len(payload), len(data), 0, 0)
        payload += data
        leaf += 1
    type_dirs += td
while len(payload) % 8:
    payload += b"\0"
blob = root + type_dirs + lang_dirs + entries + payload
assert len(root) == root_size and len(type_dirs) == type_dirs_size and len(lang_dirs) == lang_dirs_size

# COFF object for x86-64 with one .rsrc section.
IMAGE_REL_AMD64_ADDR32NB = 3
raw_ptr = 20 + 40
reloc_ptr = raw_ptr + len(blob)
sym_ptr = reloc_ptr + 10 * len(relocs)
header = struct.pack("<HHIIIHH", 0x8664, 1, 0, sym_ptr, 1, 0, 0)
section = struct.pack("<8sIIIIIIHHI", b".rsrc", 0, 0, len(blob), raw_ptr, reloc_ptr, 0, len(relocs), 0, 0x40000040)
reloc_table = b"".join(struct.pack("<IIH", at, 0, IMAGE_REL_AMD64_ADDR32NB) for at in relocs)
symbol = struct.pack("<8sIhHBB", b".rsrc", 0, 1, 0, 3, 0)
strings = struct.pack("<I", 4)
open(out, "wb").write(header + section + bytes(blob) + reloc_table + symbol + strings)
print("wrote", out, len(blob), "bytes of resources,", len(relocs), "entries")
