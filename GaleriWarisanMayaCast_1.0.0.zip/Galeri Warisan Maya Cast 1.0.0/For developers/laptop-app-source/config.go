package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
)

// configData is what the app remembers between runs.
type configData struct {
	LastIP  string  `json:"lastIp"`
	Quality string  `json:"quality"`
	Lang    string  `json:"lang"`
	Volume  float64 `json:"volume"`
	Muted   bool    `json:"muted"`
	Fill    bool    `json:"fill"`
}

type config struct {
	mu   sync.Mutex
	path string
	data configData
}

func loadConfig(dir string) *config {
	c := &config{path: filepath.Join(dir, "settings.json")}
	c.data = configData{Quality: "balanced", Lang: "en", Volume: 1}
	if b, err := os.ReadFile(c.path); err == nil {
		json.Unmarshal(b, &c.data)
	}
	if c.data.Volume < 0 || c.data.Volume > 1 {
		c.data.Volume = 1
	}
	if c.data.Lang != "ms" {
		c.data.Lang = "en"
	}
	return c
}

func (c *config) get() configData {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.data
}

func (c *config) update(fn func(*configData)) {
	c.mu.Lock()
	defer c.mu.Unlock()
	fn(&c.data)
	b, err := json.MarshalIndent(c.data, "", "  ")
	if err != nil {
		return
	}
	tmp := c.path + ".tmp"
	if os.WriteFile(tmp, b, 0o600) == nil {
		os.Rename(tmp, c.path)
	}
}
