//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
)

const exeSuffix = ""

func hideWindow(cmd *exec.Cmd) {}

func home() string {
	h, _ := os.UserHomeDir()
	return h
}

func dataDir() string {
	if d := os.Getenv("GWMCAST_DATA"); d != "" {
		return d
	}
	if d, err := os.UserConfigDir(); err == nil {
		return filepath.Join(d, "GaleriWarisanMayaCast")
	}
	return filepath.Join(home(), ".gwmcast")
}

func photosDir() string { return filepath.Join(home(), "Pictures", "Galeri Warisan Maya Cast") }
func videosDir() string { return filepath.Join(home(), "Videos", "Galeri Warisan Maya Cast") }

func adbCandidates() []string {
	return []string{filepath.Join(home(), "Android", "Sdk", "platform-tools", "adb"), "/usr/local/bin/adb"}
}

func browsers() []string {
	return []string{
		"/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
		"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
		"/usr/bin/microsoft-edge", "/usr/bin/google-chrome", "/usr/bin/chromium",
	}
}

func openDefault(url string) error {
	for _, opener := range []string{"xdg-open", "open"} {
		if p, err := exec.LookPath(opener); err == nil {
			return exec.Command(p, url).Start()
		}
	}
	return os.ErrNotExist
}

func reveal(path string) error {
	return openDefault(filepath.Dir(path))
}
