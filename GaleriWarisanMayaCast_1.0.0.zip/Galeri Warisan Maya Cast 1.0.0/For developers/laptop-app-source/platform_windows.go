package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
)

const exeSuffix = ".exe"

// hideWindow stops helper programs from flashing a console window.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

func home() string {
	if h := os.Getenv("USERPROFILE"); h != "" {
		return h
	}
	h, _ := os.UserHomeDir()
	return h
}

func dataDir() string {
	if d := os.Getenv("LOCALAPPDATA"); d != "" {
		return filepath.Join(d, "GaleriWarisanMayaCast")
	}
	return filepath.Join(home(), "AppData", "Local", "GaleriWarisanMayaCast")
}

func photosDir() string { return filepath.Join(home(), "Pictures", "Galeri Warisan Maya Cast") }
func videosDir() string { return filepath.Join(home(), "Videos", "Galeri Warisan Maya Cast") }

func adbCandidates() []string {
	local := os.Getenv("LOCALAPPDATA")
	roaming := os.Getenv("APPDATA")
	pf := os.Getenv("ProgramFiles")
	if pf == "" {
		pf = `C:\Program Files`
	}
	return []string{
		filepath.Join(local, "Android", "Sdk", "platform-tools", "adb.exe"),
		filepath.Join(pf, "Unity", "Hub", "Editor", "*", "Editor", "Data", "PlaybackEngines", "AndroidPlayer", "SDK", "platform-tools", "adb.exe"),
		filepath.Join(pf, "Meta Quest Developer Hub", "resources", "bin", "adb.exe"),
		filepath.Join(local, "Programs", "Meta Quest Developer Hub", "resources", "bin", "adb.exe"),
		filepath.Join(roaming, "SideQuest", "platform-tools", "adb.exe"),
		filepath.Join(local, "Programs", "SideQuest", "resources", "app.asar.unpacked", "build", "platform-tools", "adb.exe"),
		filepath.Join(home(), "platform-tools", "adb.exe"),
		`C:\platform-tools\adb.exe`,
		`C:\adb\adb.exe`,
	}
}

// browsers lists the programs that can show the app in a plain window of
// its own (no tabs or address bar), best first.
func browsers() []string {
	local := os.Getenv("LOCALAPPDATA")
	pf := os.Getenv("ProgramFiles")
	pf86 := os.Getenv("ProgramFiles(x86)")
	var out []string
	for _, base := range []string{pf86, pf, local} {
		if base != "" {
			out = append(out, filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
		}
	}
	for _, base := range []string{pf, pf86, local} {
		if base != "" {
			out = append(out, filepath.Join(base, "Google", "Chrome", "Application", "chrome.exe"))
		}
	}
	return out
}

// openDefault opens a web address in the default browser.
func openDefault(url string) error {
	cmd := exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	hideWindow(cmd)
	return cmd.Start()
}

// reveal shows a saved file in File Explorer.
func reveal(path string) error {
	// Explorer wants /select,"path" as written, so the command line is set
	// by hand instead of letting Go quote the arguments.
	cmd := exec.Command("explorer.exe")
	cmd.SysProcAttr = &syscall.SysProcAttr{CmdLine: `explorer.exe /select,"` + path + `"`}
	return cmd.Start()
}
