'use strict';

const boot = JSON.parse(document.getElementById('boot').textContent);
const TOKEN = boot.token;
const prefs = Object.assign({ lang: 'en', volume: 1, muted: false, fill: false }, boot.prefs || {});

// ---------- Words ----------

const WORDS = {
  en: {
    h_search: 'Looking for the headset',
    h_test: 'Starting the test picture',
    p_search: 'Put on the headset, open Galeri Warisan Maya and choose Cast to laptop. The view appears here on its own.',
    ways_label: 'Connect by',
    way_usb: 'USB cable',
    way_ip: 'Headset address',
    help_wifi: 'The laptop and the headset need to be on the same Wi-Fi. Some venue networks stop devices from seeing each other. If nothing appears after a minute, join both to a phone hotspot or use the USB cable.',
    help_usb: 'Plug the headset into this laptop with a USB-C cable. The picture travels down the cable, so no Wi-Fi is needed.',
    help_ip: 'The cast panel inside the headset shows its address, for example 192.168.1.23. Type it here.',
    btn_connect: 'Connect',
    found_one: 'Found {name} at {ip}. Connecting.',
    laptop_ip: 'This laptop is {ips}',
    needs: 'Needs headset app 1.1.0 or later',
    test_btn: 'Show a test picture',
    test_stop: 'Stop the test picture',
    live_from: 'Live from {name}',
    live_test: 'Test picture, not the headset',
    sound_on: 'Sound on',
    sound_off: 'Sound off',
    photo: 'Photo',
    record: 'Record',
    record_stop: 'Stop {time}',
    quality: 'Picture',
    q_sharp: 'Sharp',
    q_balanced: 'Balanced',
    q_light: 'Light',
    fill: 'Fill',
    fill_long: 'Fill the window, cropping the edges',
    full: 'Full screen',
    full_exit: 'Leave full screen',
    photo_saved: 'Photo saved',
    photo_failed: 'The photo could not be saved.',
    rec_saved: 'Recording saved',
    rec_failed: 'The recording could not be saved.',
    rec_unsupported: 'This laptop cannot record video in this window.',
    show_folder: 'Show in folder',
    sound_blocked: 'Click anywhere to turn the sound on',
    stalled: 'Waiting for the headset to send the next picture',
    hs_off: 'The headset has been taken off',
    hs_paused: 'The gallery is paused in the headset',
    cast_ended: 'The headset stopped casting.',
    app_gone: 'Galeri Warisan Maya Cast has closed. Close this window and start it again.',
    busy: 'Another laptop is already watching this headset. Close the cast window on that laptop first.',
    too_new: 'The headset app is newer than this laptop app. Get the latest Galeri Warisan Maya Cast.',
    not_cast: 'Something answered at that address, but it is not a Galeri Warisan Maya headset.',
    manual_no_answer: 'No answer from {ip}. Check the address, and that Cast to laptop was chosen in the headset.',
    bad_ip: 'That is not a headset address. It should be four numbers, like 192.168.1.23.',
    usb_no_adb: 'Casting by cable needs the Android debug bridge (adb), which was not found on this laptop. It is installed with SideQuest or Meta Quest Developer Hub.',
    usb_no_device: 'No headset found on the cable. Plug it in, put the headset on and choose Allow USB debugging.',
    usb_unauthorized: 'The headset is asking for permission. Put it on and choose Allow USB debugging.',
    usb_many_devices: 'More than one Android device is plugged in. Leave only the headset connected.',
    usb_error: 'The cable link could not be set up. Unplug the cable, plug it back in and wait a moment.',
    usb_app_not_casting: 'The cable is connected. Now open Galeri Warisan Maya in the headset and choose Cast to laptop.',
    test_failed: 'The test picture could not start.',
  },
  ms: {
    h_search: 'Mencari headset',
    h_test: 'Memulakan gambar ujian',
    p_search: 'Pakai headset, buka Galeri Warisan Maya dan pilih Pancar ke komputer riba. Paparan akan muncul di sini dengan sendirinya.',
    ways_label: 'Sambung melalui',
    way_usb: 'Kabel USB',
    way_ip: 'Alamat headset',
    help_wifi: 'Komputer riba dan headset perlu berada pada Wi-Fi yang sama. Sesetengah rangkaian di tempat acara menghalang peranti daripada mengesan satu sama lain. Jika tiada paparan selepas seminit, sambungkan kedua-duanya ke hotspot telefon atau gunakan kabel USB.',
    help_usb: 'Sambungkan headset ke komputer riba ini dengan kabel USB-C. Gambar dihantar melalui kabel, jadi Wi-Fi tidak diperlukan.',
    help_ip: 'Panel pancaran di dalam headset memaparkan alamatnya, contohnya 192.168.1.23. Taip alamat itu di sini.',
    btn_connect: 'Sambung',
    found_one: '{name} ditemui di {ip}. Sedang menyambung.',
    laptop_ip: 'Komputer riba ini ialah {ips}',
    needs: 'Memerlukan aplikasi headset 1.1.0 atau lebih baharu',
    test_btn: 'Tunjukkan gambar ujian',
    test_stop: 'Hentikan gambar ujian',
    live_from: 'Langsung dari {name}',
    live_test: 'Gambar ujian, bukan headset',
    sound_on: 'Bunyi hidup',
    sound_off: 'Bunyi mati',
    photo: 'Foto',
    record: 'Rakam',
    record_stop: 'Henti {time}',
    quality: 'Gambar',
    q_sharp: 'Tajam',
    q_balanced: 'Seimbang',
    q_light: 'Ringan',
    fill: 'Penuhi',
    fill_long: 'Penuhi tetingkap, tepi gambar dipotong',
    full: 'Skrin penuh',
    full_exit: 'Keluar skrin penuh',
    photo_saved: 'Gambar disimpan',
    photo_failed: 'Gambar tidak dapat disimpan.',
    rec_saved: 'Rakaman disimpan',
    rec_failed: 'Rakaman tidak dapat disimpan.',
    rec_unsupported: 'Komputer riba ini tidak dapat merakam video dalam tetingkap ini.',
    show_folder: 'Tunjuk dalam folder',
    sound_blocked: 'Klik di mana-mana untuk menghidupkan bunyi',
    stalled: 'Menunggu headset menghantar gambar seterusnya',
    hs_off: 'Headset telah ditanggalkan',
    hs_paused: 'Galeri dijeda pada headset',
    cast_ended: 'Headset berhenti memancar.',
    app_gone: 'Galeri Warisan Maya Cast telah ditutup. Tutup tetingkap ini dan mulakan semula.',
    busy: 'Komputer riba lain sedang menonton headset ini. Tutup tetingkap pancaran pada komputer itu dahulu.',
    too_new: 'Aplikasi headset lebih baharu daripada aplikasi komputer riba ini. Dapatkan Galeri Warisan Maya Cast yang terkini.',
    not_cast: 'Ada peranti menjawab di alamat itu, tetapi ia bukan headset Galeri Warisan Maya.',
    manual_no_answer: 'Tiada jawapan daripada {ip}. Semak alamat, dan pastikan Pancar ke komputer riba telah dipilih pada headset.',
    bad_ip: 'Itu bukan alamat headset. Ia sepatutnya empat nombor, seperti 192.168.1.23.',
    usb_no_adb: 'Pancaran melalui kabel memerlukan Android debug bridge (adb), yang tidak ditemui pada komputer riba ini. Ia dipasang bersama SideQuest atau Meta Quest Developer Hub.',
    usb_no_device: 'Tiada headset dikesan pada kabel. Sambungkan kabel, pakai headset dan pilih Allow USB debugging.',
    usb_unauthorized: 'Headset sedang meminta kebenaran. Pakai headset dan pilih Allow USB debugging.',
    usb_many_devices: 'Lebih daripada satu peranti Android disambungkan. Biarkan headset sahaja disambungkan.',
    usb_error: 'Pautan kabel tidak dapat disediakan. Cabut kabel, sambung semula dan tunggu sebentar.',
    usb_app_not_casting: 'Kabel telah disambungkan. Sekarang buka Galeri Warisan Maya pada headset dan pilih Pancar ke komputer riba.',
    test_failed: 'Gambar ujian tidak dapat dimulakan.',
  },
};

function t(key, vars) {
  let s = (WORDS[prefs.lang] && WORDS[prefs.lang][key]) || WORDS.en[key] || key;
  if (vars) for (const k in vars) s = s.replace('{' + k + '}', vars[k]);
  return s;
}

// ---------- Small helpers ----------

const $ = (id) => document.getElementById(id);
const body = document.body;
const stage = $('stage');
const canvas = $('screen');
const g2d = canvas.getContext('2d', { alpha: false, desynchronized: true });

async function api(path, data, raw) {
  const res = await fetch(path, {
    method: 'POST',
    headers: raw ? { 'X-GWM-Token': TOKEN } : { 'X-GWM-Token': TOKEN, 'Content-Type': 'application/json' },
    body: raw ? data : JSON.stringify(data || {}),
  });
  let out = {};
  try { out = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) throw new Error(out.problem || 'failed');
  return out;
}

function clock(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

function toast(text, action) {
  const el = document.createElement('div');
  el.className = 'toast';
  const span = document.createElement('span');
  span.textContent = text;
  el.appendChild(span);
  if (action) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = action.label;
    b.addEventListener('click', action.run);
    el.appendChild(b);
  }
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), action ? 9000 : 5000);
}

// ---------- State ----------

let st = null;            // newest status from the app
let tab = 'wifi';         // which "connect by" tab is showing
let localProblem = '';    // a problem found in the window itself (bad address)
let lastFrameAt = 0;
let shown = 0;            // pictures drawn (for tests and the stalled notice)
let soundBlocked = false;

// ---------- Picture ----------

let pendingJpeg = null;
let decoding = false;

async function drawNewest() {
  if (decoding) return;
  decoding = true;
  while (pendingJpeg) {
    const jpeg = pendingJpeg;
    pendingJpeg = null;
    try {
      const bmp = await createImageBitmap(new Blob([jpeg], { type: 'image/jpeg' }));
      if (canvas.width !== bmp.width || canvas.height !== bmp.height) {
        canvas.width = bmp.width;
        canvas.height = bmp.height;
      }
      g2d.drawImage(bmp, 0, 0);
      bmp.close();
      shown++;
      lastFrameAt = performance.now();
    } catch (e) { /* a damaged picture is skipped */ }
  }
  decoding = false;
}

function clearPicture() {
  pendingJpeg = null;
  g2d.fillStyle = '#000';
  g2d.fillRect(0, 0, canvas.width, canvas.height);
}

// ---------- Sound ----------

let actx = null, player = null, gain = null, recDest = null, audioRate = 0, audioReady = false;
const audioLevel = { buffered: 0, underruns: 0, received: 0, playing: false };

async function ensureAudio(rate) {
  if (!rate || (actx && audioRate === rate)) return;
  audioReady = false;
  if (actx) { try { await actx.close(); } catch (e) { /* already closed */ } }
  audioRate = rate;
  try {
    actx = new AudioContext({ sampleRate: rate, latencyHint: 'interactive' });
    await actx.audioWorklet.addModule('/worklet.js');
    player = new AudioWorkletNode(actx, 'pcm-player', { numberOfInputs: 0, numberOfOutputs: 1, outputChannelCount: [2] });
    player.port.onmessage = (e) => Object.assign(audioLevel, e.data);
    gain = actx.createGain();
    player.connect(gain);
    gain.connect(actx.destination);
    recDest = actx.createMediaStreamDestination();
    player.connect(recDest);
    applyVolume();
    audioReady = true;
    actx.onstatechange = checkSoundBlocked;
    if (actx.state !== 'running') actx.resume().catch(() => {});
    checkSoundBlocked();
  } catch (e) {
    actx = null; audioRate = 0;
  }
}

function checkSoundBlocked() {
  soundBlocked = !!actx && actx.state === 'suspended';
  renderNotice();
}

function applyVolume() {
  if (gain) gain.gain.value = prefs.muted ? 0 : prefs.volume;
}

function playPcm(bytes, channels) {
  if (!audioReady) return;
  const n = bytes.length >> 1;
  const view = new DataView(bytes.buffer, bytes.byteOffset, n * 2);
  const f = new Float32Array(n);
  for (let i = 0; i < n; i++) f[i] = view.getInt16(i * 2, true) / 32768;
  player.port.postMessage({ pcm: f, channels }, [f.buffer]);
}

function resetSound() {
  if (player) player.port.postMessage({ reset: true });
}

// A click or key press lets a browser that blocked sound start it.
for (const ev of ['pointerdown', 'keydown']) {
  window.addEventListener(ev, () => {
    if (actx && actx.state === 'suspended') actx.resume().catch(() => {});
  }, { capture: true });
}

// ---------- The stream from the app ----------

class ByteQueue {
  constructor() { this.chunks = []; this.len = 0; this.off = 0; }
  push(u8) { this.chunks.push(u8); this.len += u8.length; }
  peek5() {
    const out = new Uint8Array(5);
    let need = 5, ci = 0, off = this.off, o = 0;
    while (need > 0) {
      const c = this.chunks[ci];
      const take = Math.min(need, c.length - off);
      out.set(c.subarray(off, off + take), o);
      o += take; need -= take; ci++; off = 0;
    }
    return out;
  }
  take(n) {
    this.len -= n;
    const first = this.chunks[0];
    if (first.length - this.off >= n) {
      const out = first.subarray(this.off, this.off + n);
      this.off += n;
      if (this.off === first.length) { this.chunks.shift(); this.off = 0; }
      return out;
    }
    const out = new Uint8Array(n);
    let o = 0;
    while (o < n) {
      const c = this.chunks[0];
      const take = Math.min(n - o, c.length - this.off);
      out.set(c.subarray(this.off, this.off + take), o);
      o += take; this.off += take;
      if (this.off === c.length) { this.chunks.shift(); this.off = 0; }
    }
    return out;
  }
  next() {
    if (this.len < 5) return null;
    const h = this.peek5();
    const n = (h[1] | (h[2] << 8) | (h[3] << 16) | (h[4] << 24)) >>> 0;
    if (this.len < 5 + n) return null;
    this.take(5);
    return { type: h[0], payload: n ? this.take(n) : new Uint8Array(0) };
  }
}

const decoder = new TextDecoder();

function handle(type, payload) {
  if (type === 0x02) {                       // picture
    if (payload.length > 8) { pendingJpeg = payload.subarray(8); drawNewest(); }
  } else if (type === 0x03) {                // sound
    if (payload.length > 8 && st && st.headset) playPcm(payload.subarray(8), st.headset.audioChannels || 2);
  } else if (type === 0x20) {                // status
    try { applyStatus(JSON.parse(decoder.decode(payload))); } catch (e) { /* ignore */ }
  }
}

async function runStream() {
  let failures = 0;
  for (;;) {
    try {
      const res = await fetch('/stream', { headers: { 'X-GWM-Token': TOKEN }, cache: 'no-store' });
      if (!res.ok || !res.body) throw new Error('stream');
      failures = 0;
      $('gone').hidden = true;
      const reader = res.body.getReader();
      const q = new ByteQueue();
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        q.push(value);
        for (let m = q.next(); m; m = q.next()) handle(m.type, m.payload);
      }
    } catch (e) { /* the app is not answering; try again */ }
    failures++;
    if (failures >= 4) $('gone').hidden = false;
    await new Promise((r) => setTimeout(r, 700));
  }
}

// ---------- Drawing the window from the status ----------

function applyStatus(s) {
  const prev = st;
  st = s;
  body.dataset.state = s.state;
  body.dataset.mode = s.mode;
  body.dataset.test = String(!!(s.headset && s.headset.test));

  if (s.state === 'live') {
    if (!prev || prev.session !== s.session) {
      resetSound();
      lastFrameAt = performance.now();
      wake();
    }
    if (s.headset) ensureAudio(s.headset.audioRate);
  } else {
    if (prev && prev.state === 'live') {
      clearPicture();
      resetSound();
      if (recording) stopRecording();
      if (prev.mode !== 'test' && s.mode !== 'test') toast(t('cast_ended'));
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    }
  }
  // The tab follows the way of connecting only at the moment that changes,
  // so it never jumps away from what the person is looking at.
  if (!prev || prev.mode !== s.mode) {
    if (s.mode === 'manual') tab = 'ip';
    else if (s.mode === 'usb') tab = 'usb';
    else if (tab !== 'ip') tab = 'wifi';
  }
  render();
}

function renderWords() {
  document.documentElement.lang = prefs.lang === 'ms' ? 'ms' : 'en';
  for (const el of document.querySelectorAll('[data-t]')) el.textContent = t(el.dataset.t);
  for (const b of document.querySelectorAll('.lang button')) b.setAttribute('aria-pressed', String(b.dataset.lang === prefs.lang));
}

function render() {
  renderWords();
  if (!st) return;

  // Waiting screen
  $('headline').textContent = t(st.mode === 'test' ? 'h_test' : 'h_search');
  for (const b of document.querySelectorAll('.tabs button')) b.setAttribute('aria-selected', String(b.dataset.tab === tab));
  $('panel').setAttribute('aria-labelledby', 'tab-' + tab);
  $('help').textContent = t('help_' + tab);
  $('ip-form').hidden = tab !== 'ip';

  let problem = '';
  if (tab === 'ip' && localProblem) problem = t(localProblem);
  else if (st.problem && modeTab(st.mode) === tab) problem = t(st.problem, { ip: st.manualIp });
  else if (tab === 'wifi' && st.mode === 'auto' && st.found && st.found.length) problem = t('found_one', { name: st.found[0].name, ip: st.found[0].ip });
  $('problem').textContent = problem;
  $('problem').hidden = !problem;

  const ips = (st.laptopIps || []).join(', ');
  const foot = $('foot-note');
  foot.textContent = '';
  for (const line of [ips ? t('laptop_ip', { ips }) : '', t('needs'), 'v' + st.version]) {
    if (!line) continue;
    const span = document.createElement('span');
    span.textContent = line;
    foot.appendChild(span);
  }

  // Live strip
  const test = !!(st.headset && st.headset.test);
  $('who').textContent = st.headset ? (test ? t('live_test') : t('live_from', { name: st.headset.name })) : '';
  $('b-stop-test').hidden = st.mode !== 'test';
  const parts = [canvas.width + ' × ' + canvas.height];
  parts.push(Math.round(st.stats.fps) + ' fps');
  parts.push(st.stats.mbps.toFixed(1) + ' Mbps');
  if (st.stats.pingMs >= 0) parts.push(st.stats.pingMs + ' ms');
  $('stats').textContent = st.state === 'live' ? parts.join('   ') : '';

  $('b-sound').setAttribute('aria-pressed', String(!prefs.muted));
  $('l-sound').textContent = t(prefs.muted ? 'sound_off' : 'sound_on');
  $('volume').value = prefs.volume;
  $('l-fill').textContent = t('fill');
  $('b-fill').setAttribute('aria-pressed', String(prefs.fill));
  stage.classList.toggle('fill', prefs.fill);
  const fs = !!document.fullscreenElement;
  $('l-full').textContent = t(fs ? 'full_exit' : 'full');
  $('quality').value = st.quality;
  $('quality').disabled = !!recording;

  renderRecording();
  renderNotice();

  const tip = (id, key, k) => { $(id).title = t(key) + ' (' + k + ')'; $(id).setAttribute('aria-label', t(key)); };
  tip('b-sound', prefs.muted ? 'sound_off' : 'sound_on', 'M');
  tip('b-photo', 'photo', 'P');
  tip('b-record', 'record', 'R');
  tip('b-fill', 'fill_long', 'W');
  tip('b-full', fs ? 'full_exit' : 'full', 'F');
}

function modeTab(mode) { return mode === 'usb' ? 'usb' : mode === 'manual' ? 'ip' : 'wifi'; }

function renderNotice() {
  if (!st) return;
  let text = '';
  if (st.state === 'live') {
    const hs = st.headsetState || {};
    if (hs.worn === false) text = t('hs_off');
    else if (hs.paused === true) text = t('hs_paused');
    else if (performance.now() - lastFrameAt > 2500) text = t('stalled');
    else if (soundBlocked && !prefs.muted) text = t('sound_blocked');
  }
  $('notice').textContent = text;
  $('notice').hidden = !text;
}
setInterval(renderNotice, 500);

// ---------- Recording ----------

let recording = null; // { rec, id, path, started, chain, failed }

function pickMime() {
  if (!window.MediaRecorder) return '';
  // H.264 with AAC in an MP4 plays everywhere, so it comes first. A bare
  // "video/mp4" is left out on purpose: some browsers then put VP9 and Opus
  // inside the MP4, which many players refuse. WebM is the honest fallback.
  const list = [
    'video/mp4;codecs=avc1.640028,mp4a.40.2',
    'video/mp4;codecs=avc1.42E01F,mp4a.40.2',
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
  ];
  return list.find((m) => MediaRecorder.isTypeSupported(m)) || '';
}

async function startRecording() {
  if (recording || !st || st.state !== 'live') return;
  const mime = pickMime();
  if (!mime) { toast(t('rec_unsupported')); return; }
  const ext = mime.startsWith('video/mp4') ? '.mp4' : '.webm';
  let info;
  try { info = await api('/api/record/start', { ext }); } catch (e) { toast(t('rec_failed')); return; }

  const tracks = canvas.captureStream(30).getVideoTracks();
  if (recDest) tracks.push(...recDest.stream.getAudioTracks());
  let rec;
  try {
    rec = new MediaRecorder(new MediaStream(tracks), { mimeType: mime, videoBitsPerSecond: 6000000, audioBitsPerSecond: 128000 });
  } catch (e) {
    api('/api/record/stop', { id: info.id }).catch(() => {});
    toast(t('rec_unsupported'));
    return;
  }
  const me = { rec, id: info.id, path: info.path, started: performance.now(), chain: Promise.resolve(), failed: false, mime };
  recording = me;
  rec.ondataavailable = (e) => {
    if (!e.data || !e.data.size) return;
    me.chain = me.chain.then(() => api('/api/record/chunk?id=' + me.id, e.data, true)).catch(() => { me.failed = true; });
  };
  rec.onstop = async () => {
    await me.chain;
    tracks.forEach((tr) => { if (tr.kind === 'video') tr.stop(); });
    try {
      const out = await api('/api/record/stop', { id: me.id });
      if (me.failed) toast(t('rec_failed'));
      else toast(t('rec_saved'), { label: t('show_folder'), run: () => api('/api/reveal', { path: out.path }).catch(() => {}) });
    } catch (e) { toast(t('rec_failed')); }
  };
  rec.onerror = () => { me.failed = true; stopRecording(); };
  rec.start(1000);
  render();
}

function stopRecording() {
  const me = recording;
  if (!me) return;
  recording = null;
  try { if (me.rec.state !== 'inactive') me.rec.stop(); } catch (e) { /* already stopped */ }
  render();
}

function renderRecording() {
  const on = !!recording;
  const time = on ? clock((performance.now() - recording.started) / 1000) : '';
  $('b-record').setAttribute('aria-pressed', String(on));
  $('l-record').textContent = on ? t('record_stop', { time }) : t('record');
  $('rec-flag').hidden = !on;
  $('rec-flag-time').textContent = time;
}
setInterval(() => { if (recording) renderRecording(); }, 500);

// ---------- Controls ----------

function savePrefs(patch) {
  Object.assign(prefs, patch);
  api('/api/prefs', patch).catch(() => {});
  applyVolume();
  render();
}

async function takePhoto() {
  if (!st || st.state !== 'live') return;
  try {
    const out = await api('/api/photo');
    toast(t('photo_saved'), { label: t('show_folder'), run: () => api('/api/reveal', { path: out.path }).catch(() => {}) });
  } catch (e) { toast(t('photo_failed')); }
}

function toggleFull() {
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else document.documentElement.requestFullscreen().catch(() => {});
}

function setMode(mode, ip) {
  localProblem = '';
  return api('/api/mode', { mode, ip: ip || '' }).catch((e) => {
    if (e.message === 'bad_ip') { localProblem = 'bad_ip'; render(); }
  });
}

$('b-sound').addEventListener('click', () => savePrefs({ muted: !prefs.muted }));
$('volume').addEventListener('input', (e) => savePrefs({ volume: Number(e.target.value), muted: Number(e.target.value) === 0 }));
$('b-photo').addEventListener('click', takePhoto);
$('b-record').addEventListener('click', () => (recording ? stopRecording() : startRecording()));
$('b-fill').addEventListener('click', () => savePrefs({ fill: !prefs.fill }));
$('b-full').addEventListener('click', toggleFull);
$('quality').addEventListener('change', (e) => api('/api/quality', { quality: e.target.value }).catch(() => {}));
$('b-stop-test').addEventListener('click', () => setMode('auto'));
$('b-test').addEventListener('click', () => setMode('test'));
canvas.addEventListener('dblclick', toggleFull);
document.addEventListener('fullscreenchange', render);

for (const b of document.querySelectorAll('.lang button')) {
  b.addEventListener('click', () => savePrefs({ lang: b.dataset.lang }));
}

for (const b of document.querySelectorAll('.tabs button')) {
  b.addEventListener('click', () => {
    tab = b.dataset.tab;
    localProblem = '';
    if (tab === 'wifi') setMode('auto');
    else if (tab === 'usb') setMode('usb');
    else if (st && st.mode === 'usb') setMode('auto');   // stop trying the cable while an address is typed
    render();
    if (tab === 'ip') $('ip').focus();
  });
}

$('ip-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const ip = $('ip').value.trim();
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip) || ip.split('.').some((p) => Number(p) > 255)) {
    localProblem = 'bad_ip';
    render();
    return;
  }
  setMode('manual', ip);
});

window.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const tag = (e.target && e.target.tagName) || '';
  if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
  if (!st || st.state !== 'live') return;
  const k = e.key.toLowerCase();
  if (k === 'f') toggleFull();
  else if (k === 'm') savePrefs({ muted: !prefs.muted });
  else if (k === 'p') takePhoto();
  else if (k === 'w') savePrefs({ fill: !prefs.fill });
  else if (k === 'r') (recording ? stopRecording() : startRecording());
});

// The control strip steps aside when the mouse rests, so a projector shows
// only the headset view.
let idleTimer = 0;
function wake() {
  stage.classList.remove('idle');
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    if (document.querySelector('.bar :focus-visible, .bar:hover')) { wake(); return; }
    stage.classList.add('idle');
  }, 2800);
}
for (const ev of ['mousemove', 'pointerdown', 'keydown', 'touchstart']) window.addEventListener(ev, wake, { passive: true });

// ---------- The kepala kain ----------

function drawKepala() {
  const el = $('kepala');
  const w = el.clientWidth, h = el.clientHeight;
  if (!w || !h) return;
  const gold = '#d4a537', deep = '#2b0b12';
  let s = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">';
  if (h > w) {
    // Tall panel: two rows of pucuk rebung, bases meeting in the middle.
    const n = w >= 300 ? 3 : 2;
    const step = w / n;
    const th = Math.min(h * 0.37, step * 2.5);
    const mid = h / 2, band = Math.max(8, th * 0.045);
    const inset = Math.max(7, step * 0.12);
    for (const dir of [-1, 1]) {
      const baseY = mid + dir * band;
      for (let i = 0; i < n; i++) {
        const x0 = i * step;
        for (let k = 0; k < 4 && step / 2 - k * inset > 2; k++) {
          const ax = k * inset;
          const apexY = baseY + dir * (th - (ax * 2 * th) / step);
          s += '<polygon points="' + (x0 + ax) + ',' + baseY + ' ' + (x0 + step / 2) + ',' + apexY + ' ' + (x0 + step - ax) + ',' + baseY + '" fill="' + (k % 2 ? deep : gold) + '"/>';
        }
      }
      const ruleY = mid + dir * (band + th + Math.max(14, th * 0.07));
      s += '<rect x="0" y="' + (ruleY - 2.5) + '" width="' + w + '" height="5" fill="' + gold + '"/>';
    }
  } else {
    // Wide band (small windows): one row of triangles standing on the edge.
    const step = h * 0.9;
    const n = Math.ceil(w / step) + 1;
    const inset = step * 0.12;
    for (let i = 0; i < n; i++) {
      const x0 = i * step;
      for (let k = 0; k < 4 && step / 2 - k * inset > 2; k++) {
        const ax = k * inset;
        const apexY = h - (h * 0.92 - (ax * 2 * h * 0.92) / step);
        s += '<polygon points="' + (x0 + ax) + ',' + h + ' ' + (x0 + step / 2) + ',' + apexY + ' ' + (x0 + step - ax) + ',' + h + '" fill="' + (k % 2 ? deep : gold) + '"/>';
      }
    }
  }
  el.innerHTML = s + '</svg>';
}
window.addEventListener('resize', drawKepala);

// ---------- Start ----------

// Handy for checking a setup from the developer console, and for tests.
window.gwm = { get status() { return st; }, get shown() { return shown; }, audio: audioLevel, get recording() { return !!recording; }, get soundState() { return actx ? actx.state : 'none'; } };

drawKepala();
renderWords();
runStream();
