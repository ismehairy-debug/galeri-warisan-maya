// Plays the headset's sound. Samples arrive in small chunks over the
// network; this keeps a short reserve so the sound does not stutter, and
// skips ahead if the reserve grows, so sound never drifts behind the picture.
class PcmPlayer extends AudioWorkletProcessor {
  constructor() {
    super();
    this.cap = sampleRate * 2;                     // frames of room (two seconds)
    this.buf = new Float32Array(this.cap * 2);     // stereo, interleaved
    this.r = 0;
    this.count = 0;
    this.playing = false;
    this.target = Math.round(sampleRate * 0.12);   // reserve before starting
    this.max = Math.round(sampleRate * 0.45);      // more than this is too far behind
    this.underruns = 0;
    this.received = 0;
    this.sinceReport = 0;
    this.port.onmessage = (e) => {
      const d = e.data;
      if (d.reset) {
        this.r = 0; this.count = 0; this.playing = false;
      } else if (d.pcm) {
        this.push(d.pcm, d.channels || 2);
      }
    };
  }

  push(pcm, ch) {
    const frames = Math.floor(pcm.length / ch);
    this.received += frames;
    let w = (this.r + this.count) % this.cap;
    for (let i = 0; i < frames; i++) {
      const l = pcm[i * ch];
      const rgt = ch > 1 ? pcm[i * ch + 1] : l;
      if (this.count === this.cap) {               // full: drop the oldest
        this.r = (this.r + 1) % this.cap;
        this.count--;
      }
      this.buf[w * 2] = l;
      this.buf[w * 2 + 1] = rgt;
      w = (w + 1) % this.cap;
      this.count++;
    }
  }

  process(inputs, outputs) {
    const out = outputs[0];
    const L = out[0];
    const R = out[1] || out[0];
    const n = L.length;

    if (!this.playing && this.count >= this.target) this.playing = true;
    if (this.playing && this.count > this.max) {
      const drop = this.count - this.target;
      this.r = (this.r + drop) % this.cap;
      this.count -= drop;
    }
    if (this.playing) {
      const take = Math.min(n, this.count);
      for (let i = 0; i < take; i++) {
        L[i] = this.buf[this.r * 2];
        R[i] = this.buf[this.r * 2 + 1];
        this.r = (this.r + 1) % this.cap;
      }
      this.count -= take;
      if (take < n) {                              // ran dry: rebuild the reserve
        this.playing = false;
        this.underruns++;
      }
    }

    this.sinceReport += n;
    if (this.sinceReport >= sampleRate / 2) {
      this.sinceReport = 0;
      this.port.postMessage({ buffered: this.count / sampleRate, underruns: this.underruns, received: this.received, playing: this.playing });
    }
    return true;
  }
}
registerProcessor('pcm-player', PcmPlayer);
