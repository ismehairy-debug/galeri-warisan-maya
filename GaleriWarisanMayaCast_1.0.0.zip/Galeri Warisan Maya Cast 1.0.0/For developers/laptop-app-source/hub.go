package main

import (
	"sync"
	"time"
)

// hub passes what arrives from the headset on to the app's own window(s).
// Video keeps only the newest frame per window so a slow window never builds
// up delay; audio is queued (bounded) because gaps in sound are audible.
type hub struct {
	mu            sync.Mutex
	clients       map[*uiClient]struct{}
	lastVideo     []byte // framed, newest frame from the headset
	lastStatus    []byte // framed
	everConnected bool
	lastGone      time.Time
}

const maxAudioQueue = 100 // about two seconds of 20 ms chunks

type uiClient struct {
	mu     sync.Mutex
	cond   *sync.Cond
	video  []byte
	audio  [][]byte
	status []byte
	closed bool
}

func newHub() *hub {
	return &hub{clients: map[*uiClient]struct{}{}, lastGone: time.Now()}
}

func (h *hub) add() *uiClient {
	c := &uiClient{}
	c.cond = sync.NewCond(&c.mu)
	h.mu.Lock()
	h.clients[c] = struct{}{}
	h.everConnected = true
	c.status = h.lastStatus
	c.video = h.lastVideo
	h.mu.Unlock()
	return c
}

func (h *hub) remove(c *uiClient) {
	c.close()
	h.mu.Lock()
	delete(h.clients, c)
	if len(h.clients) == 0 {
		h.lastGone = time.Now()
	}
	h.mu.Unlock()
}

func (h *hub) count() int {
	h.mu.Lock()
	defer h.mu.Unlock()
	return len(h.clients)
}

// idle reports whether a window was once open and how long none has been.
func (h *hub) idle() (ever bool, gone time.Duration) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if len(h.clients) > 0 {
		return h.everConnected, 0
	}
	return h.everConnected, time.Since(h.lastGone)
}

func (h *hub) each(fn func(c *uiClient)) {
	h.mu.Lock()
	list := make([]*uiClient, 0, len(h.clients))
	for c := range h.clients {
		list = append(list, c)
	}
	h.mu.Unlock()
	for _, c := range list {
		c.mu.Lock()
		fn(c)
		c.mu.Unlock()
		c.cond.Signal()
	}
}

func (h *hub) video(framed []byte) {
	h.mu.Lock()
	h.lastVideo = framed
	h.mu.Unlock()
	h.each(func(c *uiClient) { c.video = framed })
}

func (h *hub) audio(framed []byte) {
	h.each(func(c *uiClient) {
		if len(c.audio) >= maxAudioQueue {
			c.audio = append(c.audio[:0], c.audio[maxAudioQueue/2:]...)
		}
		c.audio = append(c.audio, framed)
	})
}

func (h *hub) status(framed []byte) {
	h.mu.Lock()
	h.lastStatus = framed
	h.mu.Unlock()
	h.each(func(c *uiClient) { c.status = framed })
}

// clearVideo forgets the last frame when the headset goes away, so a window
// opened later does not show a stale picture.
func (h *hub) clearVideo() {
	h.mu.Lock()
	h.lastVideo = nil
	h.mu.Unlock()
	h.each(func(c *uiClient) { c.video = nil; c.audio = nil })
}

// latestJPEG returns the newest picture from the headset, or nil.
func (h *hub) latestJPEG() []byte {
	h.mu.Lock()
	defer h.mu.Unlock()
	if len(h.lastVideo) < 13 {
		return nil
	}
	return h.lastVideo[13:]
}

func (c *uiClient) close() {
	c.mu.Lock()
	c.closed = true
	c.mu.Unlock()
	c.cond.Broadcast()
}

// next blocks until there is something to send. ok is false once closed.
func (c *uiClient) next() (status []byte, audio [][]byte, video []byte, ok bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for !c.closed && c.status == nil && len(c.audio) == 0 && c.video == nil {
		c.cond.Wait()
	}
	if c.closed {
		return nil, nil, nil, false
	}
	status, audio, video = c.status, c.audio, c.video
	c.status, c.audio, c.video = nil, nil, nil
	return status, audio, video, true
}
