// gwmsim pretends to be a headset on the real cast ports. It exists for
// testing the laptop app; the laptop app's own "test picture" uses the same
// code in-process.
package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"

	"gwmcast/sim"
	"gwmcast/wire"
)

func main() {
	addr := flag.String("addr", fmt.Sprintf(":%d", wire.CastPort), "TCP listen address")
	name := flag.String("name", "Simulated Quest 3", "headset name to announce")
	noUDP := flag.Bool("no-discovery", false, "do not answer discovery probes")
	flag.Parse()

	s, err := sim.Start(sim.Options{
		Name: *name, Version: "1.1.0-sim", TCPAddr: *addr, Discovery: !*noUDP, Logf: log.Printf,
	})
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("simulated headset listening on %s", s.Addr())
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, os.Interrupt)
	<-ch
	s.Close()
}
