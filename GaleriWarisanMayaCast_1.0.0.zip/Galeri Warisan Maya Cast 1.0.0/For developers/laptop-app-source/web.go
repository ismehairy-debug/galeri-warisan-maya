package main

import (
	"bytes"
	"crypto/subtle"
	"embed"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"path/filepath"
	"strings"
	"time"
)

//go:embed ui
var uiFS embed.FS

type server struct {
	m     *manager
	hub   *hub
	cfg   *config
	rec   *recorder
	token string
	port  int
	quit  func()
}

var staticTypes = map[string]string{
	"/app.css":     "text/css; charset=utf-8",
	"/app.js":      "text/javascript; charset=utf-8",
	"/worklet.js":  "text/javascript; charset=utf-8",
	"/gelasio.ttf": "font/ttf",
	"/icon.png":    "image/png",
}

func (s *server) handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", s.index)
	for path, typ := range staticTypes {
		mux.HandleFunc("GET "+path, s.static(path, typ))
	}
	mux.HandleFunc("GET /stream", s.stream)
	mux.HandleFunc("GET /api/ping", s.ping)
	mux.HandleFunc("POST /api/mode", s.mode)
	mux.HandleFunc("POST /api/quality", s.quality)
	mux.HandleFunc("POST /api/prefs", s.prefs)
	mux.HandleFunc("POST /api/photo", s.photo)
	mux.HandleFunc("POST /api/record/start", s.recStart)
	mux.HandleFunc("POST /api/record/chunk", s.recChunk)
	mux.HandleFunc("POST /api/record/stop", s.recStop)
	mux.HandleFunc("POST /api/reveal", s.reveal)
	mux.HandleFunc("POST /api/quit", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]bool{"ok": true})
		go s.quit()
	})
	return s.guard(mux)
}

// guard keeps the app's local web address private to the app's own window:
// requests must be addressed to this computer, come from the app's own
// page, and (except for static files) carry the per-run token.
func (s *server) guard(next http.Handler) http.Handler {
	hosts := map[string]bool{
		fmt.Sprintf("127.0.0.1:%d", s.port): true,
		fmt.Sprintf("localhost:%d", s.port): true,
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !hosts[r.Host] {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		if o := r.Header.Get("Origin"); o != "" && !hosts[strings.TrimPrefix(o, "http://")] {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		h := w.Header()
		h.Set("Cache-Control", "no-store")
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", "default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
		if _, ok := staticTypes[r.URL.Path]; !ok {
			tok := r.Header.Get("X-GWM-Token")
			if tok == "" {
				tok = r.URL.Query().Get("t")
			}
			if subtle.ConstantTimeCompare([]byte(tok), []byte(s.token)) != 1 {
				http.Error(w, "forbidden", http.StatusForbidden)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, code int, problem string) {
	writeJSON(w, code, map[string]string{"problem": problem})
}

func readJSON(r *http.Request, v any) error {
	return json.NewDecoder(io.LimitReader(r.Body, 1<<16)).Decode(v)
}

func (s *server) index(w http.ResponseWriter, r *http.Request) {
	page, err := uiFS.ReadFile("ui/index.html")
	if err != nil {
		http.Error(w, "missing page", 500)
		return
	}
	boot, _ := json.Marshal(map[string]any{
		"token": s.token, "version": version, "prefs": s.cfg.get(),
	})
	// "<" cannot appear in the JSON we generate except inside strings we
	// control, but escape it anyway so the block can never be closed early.
	boot = bytes.ReplaceAll(boot, []byte("<"), []byte(`<`))
	page = bytes.Replace(page, []byte("{{BOOT}}"), boot, 1)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write(page)
}

func (s *server) static(path, typ string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		b, err := uiFS.ReadFile("ui" + path)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", typ)
		w.Write(b)
	}
}

func (s *server) ping(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, map[string]string{"app": "gwmcast", "version": version})
}

// stream is the one long-lived request the window keeps open: status,
// sound and pictures, framed the same way the headset frames them.
func (s *server) stream(w http.ResponseWriter, r *http.Request) {
	rc := http.NewResponseController(w)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.WriteHeader(200)
	rc.Flush()

	c := s.hub.add()
	defer s.hub.remove(c)
	go func() { <-r.Context().Done(); c.close() }()
	s.m.pushStatus()

	for {
		st, audio, video, ok := c.next()
		if !ok {
			return
		}
		rc.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if st != nil {
			if _, err := w.Write(st); err != nil {
				return
			}
		}
		for _, a := range audio {
			if _, err := w.Write(a); err != nil {
				return
			}
		}
		if video != nil {
			if _, err := w.Write(video); err != nil {
				return
			}
		}
		if rc.Flush() != nil {
			return
		}
	}
}

func (s *server) mode(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Mode string `json:"mode"`
		IP   string `json:"ip"`
	}
	if readJSON(r, &req) != nil {
		fail(w, 400, "bad_request")
		return
	}
	if err := s.m.setMode(req.Mode, strings.TrimSpace(req.IP)); err != nil {
		fail(w, 400, err.Error())
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *server) quality(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Quality string `json:"quality"`
	}
	if readJSON(r, &req) != nil || s.m.setQuality(req.Quality) != nil {
		fail(w, 400, "bad_request")
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *server) prefs(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Lang   *string  `json:"lang"`
		Volume *float64 `json:"volume"`
		Muted  *bool    `json:"muted"`
		Fill   *bool    `json:"fill"`
	}
	if readJSON(r, &req) != nil {
		fail(w, 400, "bad_request")
		return
	}
	s.cfg.update(func(c *configData) {
		if req.Lang != nil && (*req.Lang == "en" || *req.Lang == "ms") {
			c.Lang = *req.Lang
		}
		if req.Volume != nil && *req.Volume >= 0 && *req.Volume <= 1 {
			c.Volume = *req.Volume
		}
		if req.Muted != nil {
			c.Muted = *req.Muted
		}
		if req.Fill != nil {
			c.Fill = *req.Fill
		}
	})
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *server) photo(w http.ResponseWriter, r *http.Request) {
	p, err := s.rec.savePhoto(s.hub.latestJPEG())
	if err != nil {
		fail(w, 409, "photo_failed")
		return
	}
	writeJSON(w, 200, map[string]string{"path": p, "name": filepath.Base(p)})
}

func (s *server) recStart(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Ext string `json:"ext"`
	}
	if readJSON(r, &req) != nil {
		fail(w, 400, "bad_request")
		return
	}
	id, p, err := s.rec.start(req.Ext)
	if err != nil {
		fail(w, 409, "record_failed")
		return
	}
	s.m.pushStatus()
	writeJSON(w, 200, map[string]string{"id": id, "path": p})
}

func (s *server) recChunk(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, 128<<20))
	if err != nil {
		fail(w, 413, "chunk_too_large")
		return
	}
	if err := s.rec.write(r.URL.Query().Get("id"), body); err != nil {
		fail(w, 409, "record_failed")
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *server) recStop(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ID string `json:"id"`
	}
	if readJSON(r, &req) != nil || req.ID == "" {
		fail(w, 400, "bad_request")
		return
	}
	p, err := s.rec.stop(req.ID)
	s.m.pushStatus()
	if p == "" {
		fail(w, 409, "record_failed")
		return
	}
	_ = err
	writeJSON(w, 200, map[string]string{"path": p, "name": filepath.Base(p)})
}

// reveal shows a saved photo or recording in the file manager. Only files
// inside the app's own two folders are accepted.
func (s *server) reveal(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Path string `json:"path"`
	}
	if readJSON(r, &req) != nil {
		fail(w, 400, "bad_request")
		return
	}
	p := filepath.Clean(req.Path)
	dir := filepath.Dir(p)
	if dir != filepath.Clean(s.rec.photoDir) && dir != filepath.Clean(s.rec.videoDir) {
		fail(w, 403, "forbidden")
		return
	}
	if err := reveal(p); err != nil {
		fail(w, 500, "reveal_failed")
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}
