# For developers

## laptop-app-source

The laptop app, in Go (1.22 or later), standard library only.

    go build -o gwmcast .                       # for the machine you are on
    go run ./cmd/gwmsim                         # a simulated headset on the real ports
    GOOS=windows GOARCH=amd64 CGO_ENABLED=0 \
      go build -trimpath -ldflags "-s -w -H=windowsgui" -o GaleriWarisanMayaCast.exe .

- `main.go` start-up, the window, quitting. `session.go` the connection to
  the headset. `discover.go` finding it. `hub.go` and `web.go` pass the
  stream to the window. `record.go` photos and recordings. `usb.go` the
  cable. `ui/` the window itself. `wire/` the protocol. `sim/` the
  simulated headset and test picture.
- `rsrc_windows_amd64.syso` is the program icon; `python3 tools/make_syso.py
  assets/icon-1024.png rsrc_windows_amd64.syso` rebuilds it (needs Pillow).
- Useful switches: `-no-browser -port 47910` prints the window's address
  instead of opening it; `-mode test`; `-mode manual -ip 192.168.1.23`;
  `-grab picture.jpg` connects, saves one picture plus `picture.jpg.json`
  with what it saw, and exits.

## headset-app-draft

Four C# scripts for the Unity project: the network server, the spectator
camera and JPEG encoder, the audio tap, and a small switch that ties them
together. They are a draft written to the protocol; they have not been
compiled in Unity or run on a headset. Still to do in the Unity project:

1. Add the scripts and the start-up prompt ("Cast to laptop" / "Skip") in
   the app's own board style, calling `GWMCast.Ensure().StartCasting()`.
2. Allow network access in Player Settings (the 1.0.0 app has none).
3. On the headset, check picture orientation and colours, hide eye-locked
   overlays from the spectator camera, check that video-player sound
   reaches the AudioListener, and measure the frame-rate cost at each
   picture setting.
4. Raise the version to 1.1.0 (version code 110), rebuild and sign.

See PROTOCOL.md for the wire format.
