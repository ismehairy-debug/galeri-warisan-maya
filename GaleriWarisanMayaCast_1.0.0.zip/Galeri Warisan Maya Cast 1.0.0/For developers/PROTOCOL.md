# Galeri Warisan Maya Cast protocol, version 1

The headset is the server. Nothing listens until casting is switched on in
the headset.

| Port | Use |
| --- | --- |
| TCP 47800 | The cast connection. One laptop at a time. |
| UDP 47801 | Discovery. The laptop broadcasts the ASCII text `GWMCAST1?`; the headset answers the sender with JSON `{"app":"GWMCAST","proto":1,"name":"…","port":47800,"ver":"1.1.0","busy":false}`. |

Over USB the laptop runs `adb forward tcp:47800 tcp:47800` and connects to
127.0.0.1, so the headset must accept loopback connections.

## Messages

Every TCP message is `[1 byte type][4 bytes payload length, little-endian][payload]`.

| Type | Direction | Payload |
| --- | --- | --- |
| 0x01 Hello | headset → laptop | JSON `{"app":"GWMCAST","proto":1,"name","appVersion","width","height","fps","audioRate","audioChannels"}`. Sent as soon as the laptop connects. |
| 0x10 ClientHello | laptop → headset | JSON `{"proto":1,"name":"<computer name>","app":"GaleriWarisanMayaCast/1.0.0"}`. The headset sends no picture or sound until this arrives (3 s limit). |
| 0x11 Config | laptop → headset | JSON `{"maxHeight":540,"fps":30,"quality":70}`: maxHeight is 720, 540 or 432; fps 5 to 60; quality 20 to 95. Sent after ClientHello and whenever the person changes the Picture setting. Picture is 16:9. |
| 0x02 Video | headset → laptop | 8-byte little-endian timestamp in milliseconds, then one complete JPEG. |
| 0x03 Audio | headset → laptop | 8-byte little-endian timestamp in milliseconds, then signed 16-bit little-endian interleaved PCM at the Hello's rate and channel count. About 20 ms per message. |
| 0x04 State | headset → laptop | JSON `{"worn":true,"paused":false}`; either key may be left out. The laptop shows a notice when `worn` is false or `paused` is true. |
| 0x05 Ping | laptop → headset | 8 opaque bytes, once a second. |
| 0x06 Pong | headset → laptop | The same 8 bytes. |
| 0x07 Bye | either | JSON `{"reason":"busy"}` or `{"reason":"ended"}`. `busy` is sent instead of Hello when another laptop is already watching. |

Rules the laptop app relies on:

- The first message on a new connection is Hello or Bye. Anything else, or
  silence for about a second, and the laptop treats the address as "not a
  headset".
- The headset keeps only the newest picture waiting to be sent. If the
  network is slow it skips pictures; it never queues them.
- The laptop gives up on a connection after 5 s without any message, so the
  headset should answer pings even when no picture is being produced.
- The headset should only accept private, link-local and loopback
  addresses.

## How the laptop finds the headset (Wi-Fi tab)

Each round, in order: the address that worked last time; a discovery
broadcast on every local network; and, on the third round and then about
every ten seconds while nothing answers, a TCP connection attempt to port
47800 on each of the up to 254 neighbours in the laptop's own /24. The last
step is for networks that drop broadcasts.

## Reference implementations

- `laptop-app-source/sim/sim.go`: a simulated headset (also the laptop
  app's built-in test picture). `go run ./cmd/gwmsim` runs it on the real
  ports.
- `headset-app-draft/GWMCastServer.cs`: the same thing for Unity. Draft:
  not yet compiled in Unity or run on a Quest.
